<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      VARIABLES                       //
	//------------------------------------------------------//
	
	//Only allow script to continue if it's the main admin user generating a password for a brand
	if(get_app_info('is_sub_user')) exit;
	
	//Init
	$app = isset($_POST['app']) && is_numeric($_POST['app']) ? mysqli_real_escape_string($mysqli, (int)$_POST['app']) : exit;
	sendy_require_access(sendy_can_access_app($app));
	$company = mysqli_real_escape_string($mysqli, $_POST['brand_name']);
	$name = mysqli_real_escape_string($mysqli, $_POST['from_name']);
	$username = mysqli_real_escape_string($mysqli, $_POST['from_email']);
	$password = ran_string(12, 12, true, false, true);
	$pass_encrypted = hash('sha512', $password.'PectGtma');
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	$q = 'SELECT id FROM login WHERE app = '.$app;
	$r = mysqli_query($mysqli, $q);
	if ($r && mysqli_num_rows($r) > 0)
	{
		$brand_user_ids = array();
		while($row = mysqli_fetch_array($r)) $brand_user_ids[] = (int)$row['id'];

		//update password
	    $q = 'UPDATE login SET password = "'.$pass_encrypted.'" WHERE app = '.$app;
	    $r = mysqli_query($mysqli, $q);
	    if ($r)
	    {
	    	//New password signs the brand's users out on every device
	    	foreach($brand_user_ids as $brand_user_id) sendy_login_tokens_revoke_user($brand_user_id, false);
	    	echo $password;
	    }
	}
	else
	{
		//insert new record
		$q = 'INSERT INTO login (name, company, username, password, tied_to, app) VALUES ("'.$name.'", "'.$company.'", "'.$username.'", "'.$pass_encrypted.'", '.get_app_info('userID').', '.$app.')';
		$r = mysqli_query($mysqli, $q);
		if ($r)  echo $password;
	}
?>