<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      	INIT                       //
	//------------------------------------------------------//
	
	$app_id = isset($_POST['id']) && is_numeric($_POST['id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['id']) : exit;
	sendy_require_access(sendy_can_access_app($app_id));
	$filename = mysqli_real_escape_string($mysqli, filter_var($_POST['filename'],FILTER_SANITIZE_SPECIAL_CHARS));
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//delete file
	$logo_path = sendy_existing_uploads_path($app_id, 'logos/'.basename($filename), '../../uploads');
	if(unlink($logo_path))
	{
		//Remove filename from database
		$q = 'UPDATE apps SET brand_logo_filename = \'\' WHERE id = '.$app_id;
		$r = mysqli_query($mysqli, $q);
		if ($r) echo true;
	}
?>
