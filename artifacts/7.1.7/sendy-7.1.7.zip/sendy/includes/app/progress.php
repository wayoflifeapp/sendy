<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 	
	//init
	$campaign_id = isset($_POST['campaign_id']) && is_numeric($_POST['campaign_id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['campaign_id']) : exit;
	sendy_require_access(sendy_can_access_campaign($campaign_id));
	$loader = get_app_info('dark_mode') ? 'loader-dark.gif' : 'loader-light.gif';
	
	//get send count
	$q = 'SELECT to_send, recipients, send_status, send_error FROM campaigns WHERE id = '.$campaign_id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$to_send = $row['to_send'];
			$recipients = $row['recipients'];
			$send_status = $row['send_status'];
			$send_error = $row['send_error'];
	    }  
	}

	//This is a read-only progress display. A momentary "no lock owner while a
	//durable SES batch claim exists" snapshot can occur while the sender is
	//reconnecting after a lost connection (see scheduled.php's heartbeat)
	//and does not by itself mean the sender failed, so it must never be
	//persisted here. Only the sender itself (scheduled.php / send-now.php /
	//the Amazon SES helper) may write campaigns.send_status = 'interrupted',
	//and only after it has actually tried and failed to recover.

	$percentage = $recipients!=0 ? $recipients / $to_send * 100 : 0;
	
	if($send_status=='interrupted')
		echo '<span data-sendy-interrupted="1" class="text-error" title="'.htmlspecialchars($send_error, ENT_QUOTES, 'UTF-8').'">'.$recipients.' <span>('.round($percentage).'%)</span> - '._('Interrupted').'</span>';
	else if($to_send == $recipients)
		echo $recipients;
	else
		echo $recipients.' <span style="color:#488846;">('.round($percentage).'%)</span> <img src="'.get_app_info('path').'/img/'.$loader.'" style="width:16px;"/>';
?>
