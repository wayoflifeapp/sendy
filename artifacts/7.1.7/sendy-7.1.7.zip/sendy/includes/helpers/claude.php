<?php

require_once(dirname(__FILE__).'/ai-client-base.php');

class SendyClaudeAiClient extends SendyAiClientBase
{
	private $api_base = 'https://api.anthropic.com/v1';
	private $model = 'claude-sonnet-5';
	private $api_version = '2023-06-01';

	public function __construct($api_key, $options = array())
	{
		parent::__construct($api_key, $options);

		if(isset($options['api_base']) && trim($options['api_base'])!='')
			$this->api_base = rtrim($options['api_base'], '/');

		if(isset($options['model']) && trim($options['model'])!='')
			$this->model = trim($options['model']);
	}

	public function create_message($payload)
	{
		return $this->request('POST', '/messages', $payload);
	}

	public function generate_subject_line($html, $plain_text='', $current_subject='', $prompt_mode='compelling', $custom_prompt='')
	{
		$content = $this->build_subject_source($html, $plain_text);

		if($content=='')
			throw new Exception(_('Email content is required to generate a subject line.'));

		$payload = array(
			'model' => $this->model,
			'max_tokens' => 60,
			'thinking' => array('type' => 'disabled'),
			'system' => 'You write email subject lines. Return exactly one subject line as plain text. Do not add quotation marks, labels, numbering, markdown, or commentary.',
			'messages' => array(
				array('role' => 'user', 'content' => $this->build_subject_prompt($content, $current_subject, $prompt_mode, $custom_prompt))
			)
		);

		$response = $this->create_message($payload);
		$subject = $this->extract_output_text($response);
		$subject = $this->sanitize_subject_line($subject);

		if($subject=='')
			throw new Exception(_('Claude returned an empty subject line.'));

		return $subject;
	}

	public function generate_campaign_report_analysis($metrics)
	{
		if(!is_array($metrics) || count($metrics)==0)
			throw new Exception(_('Campaign report metrics are required.'));

		$metrics_json = json_encode($metrics);
		if($metrics_json===false)
			throw new Exception(_('Unable to encode campaign report metrics.'));

		$payload = array(
			'model' => $this->model,
			'max_tokens' => 1800,
			'thinking' => array('type' => 'disabled'),
			'system' => 'You are a friendly email marketing coach. Analyze campaign or autoresponder report metrics in a personal, conversational tone, like you are advising the sender directly. Be warm, clear, and practical rather than corporate or business-like. Include CTOR/click-to-open-rate analysis and geographic/country open data when present. Do not invent benchmarks or unsupported causes. If tracking is disabled or data is thin, say so and focus on what can still be learned. Return a safe HTML fragment only, using <p>, <strong>, <ul>, <ol>, and <li>. Section titles must be bold with <strong>. Put bullet or numbered points inside proper <ul> or <ol> lists. Do not use emojis. Do not include a "Campaign Analysis" title. Keep the analysis concise enough to finish completely, and make sure the final recommendation ends as a complete sentence.',
			'messages' => array(
				array('role' => 'user', 'content' => "Analyze this Sendy email report. Include: (1) a short performance summary, (2) the main strengths and risks visible in the metrics, (3) CTOR/click-to-open-rate and what it suggests about content and calls to action, (4) what the country/open geography data suggests, and (5) specific recommendations for future campaigns.\n\nMetrics JSON:\n".$metrics_json)
			)
		);

		$response = $this->create_message($payload);
		$analysis = trim($this->extract_output_text($response));

		if($analysis=='')
			throw new Exception(_('Claude returned an empty campaign analysis.'));

		return $this->limit_text($analysis, 12000);
	}

	public function generate_campaign_report_score($metrics)
	{
		if(!is_array($metrics) || count($metrics)==0)
			throw new Exception(_('Campaign report metrics are required.'));

		$metrics_json = json_encode($metrics);
		if($metrics_json===false)
			throw new Exception(_('Unable to encode campaign report metrics.'));

		$payload = array(
			'model' => $this->model,
			'max_tokens' => 20,
			'thinking' => array('type' => 'disabled'),
			'system' => 'You score email marketing campaign reports. Return exactly one integer from 0 to 100 and nothing else. Score the campaign using only the supplied metrics: engagement, click-to-open rate, deliverability, unsubscribes, complaints, bounces, tracking availability, and amount of data. Do not invent industry benchmarks.',
			'messages' => array(
				array('role' => 'user', 'content' => "Give this Sendy email report a campaign score out of 100.\n\nMetrics JSON:\n".$metrics_json)
			)
		);

		$response = $this->create_message($payload);
		$score_text = trim($this->extract_output_text($response));

		if(!preg_match('/\b(100|[1-9]?[0-9])\b/', $score_text, $matches))
			throw new Exception(_('Claude returned an invalid campaign score.'));

		return max(0, min(100, (int)$matches[1]));
	}

	public function generate_email_content_improvements($html, $plain_text='', $current_subject='')
	{
		$content = $this->build_subject_source($html, $plain_text);
		$current_subject = $this->sanitize_subject_line($current_subject);

		if($content=='')
			throw new Exception(_('Write some email content first, then I can suggest improvements.'));

		$subject_context = $current_subject!='' ? "Current subject line:\n".$current_subject."\n\n" : '';

		$payload = array(
			'model' => $this->model,
			'max_tokens' => 1800,
			'thinking' => array('type' => 'disabled'),
			'system' => 'You are a friendly email marketing coach. Review the current email content and suggest practical improvements in a personal, conversational tone, like you are advising the sender directly. Focus only on what is visible in the email content. Do not invent audience details, goals, metrics, product claims, or benchmarks. For each meaningful improvement, include a concrete example of how you would rewrite the relevant portion, while preserving the sender\'s likely intent. Return a safe HTML fragment only, using <p>, <strong>, <ul>, <ol>, and <li>. Section titles must be bold with <strong>. Put bullet or numbered points inside proper <ul> or <ol> lists. Do not include an "Email Analysis" title. Keep the response concise and actionable, and make sure the final recommendation ends as a complete sentence.',
			'messages' => array(
				array('role' => 'user', 'content' => "Suggest improvements for this email before it is sent. Include: (1) a short summary of what the email is trying to do, (2) strengths worth keeping, (3) specific improvements to clarity, structure, persuasion, and calls to action, (4) rewrite examples for the portions you say can be improved, (5) any deliverability or readability risks visible in the content, and (6) a short prioritized checklist of changes to make next. When giving rewrite examples, quote or describe the original portion briefly, then provide a better version the sender could use.\n\n".$subject_context."Email content:\n".$content)
			)
		);

		$response = $this->create_message($payload);
		$analysis = trim($this->extract_output_text($response));

		if($analysis=='')
			throw new Exception(_('Claude returned an empty improvement suggestion.'));

		return $this->limit_text($analysis, 12000);
	}

	public function generate_email_newsletter_html($prompt)
	{
		$prompt = trim((string)$prompt);

		if($prompt=='')
			throw new Exception(_('A prompt is required to generate an email.'));

		$payload = array(
			'model' => $this->model,
			'max_tokens' => 8000,
			'thinking' => array('type' => 'disabled'),
			'system' => 'Create the email requested by the user. If reference email context is provided, use it only when it matches the user\'s requested visual direction, color scheme, spacing, or layout inspiration. When the user asks to follow the reference color scheme, palette, colors, background, or dark/light theme, the reference palette must override generic defaults such as clean white background, simple white layout, or neutral styling. For HTML emails, web version links must use href="[webversion]" exactly and unsubscribe links must use href="[unsubscribe]" exactly. If the user requests HTML, return complete HTML only. If the user requests plain text, return plain text only. Do not include markdown fences, explanations, labels, or commentary.',
			'messages' => array(
				array('role' => 'user', 'content' => $prompt)
			)
		);

		$response = $this->create_message($payload);
		$html = trim($this->extract_output_text($response));
		$html = $this->strip_markdown_code_fence($html);

		if($html=='')
			throw new Exception(_('Claude returned empty email HTML.'));

		return $html;
	}

	private function request($method, $path, $payload=null)
	{
		if($this->api_key=='')
			throw new Exception(_('Claude API key is missing.'));

		if(!function_exists('curl_init'))
			throw new Exception(_('cURL is required to call the Claude API.'));

		$url = $this->api_base.$path;
		$ch = curl_init();
		$headers = array(
			'Content-Type: application/json',
			'x-api-key: '.$this->api_key,
			'anthropic-version: '.$this->api_version
		);

		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, $this->timeout);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Sendy AI/1.0');

		if(file_exists($this->ca_cert_path))
			curl_setopt($ch, CURLOPT_CAINFO, $this->ca_cert_path);

		if($payload!==null)
		{
			$payload_json = json_encode($payload);
			if($payload_json===false)
				throw new Exception(_('Unable to encode the Claude API request.'));

			curl_setopt($ch, CURLOPT_POSTFIELDS, $payload_json);
		}

		$body = curl_exec($ch);
		$curl_error = curl_error($ch);
		$status_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
		if(PHP_VERSION_ID < 80000) curl_close($ch);

		if($body===false)
			throw new Exception($curl_error!='' ? $curl_error : _('Unable to reach the Claude API.'));

		$data = json_decode($body, true);
		if(!is_array($data))
		{
			$json_error = function_exists('json_last_error_msg') ? json_last_error_msg() : _('Unable to decode JSON.');
			throw new Exception($json_error);
		}

		if($status_code<200 || $status_code>=300)
		{
			$error_message = $this->extract_error_message($data);
			if($error_message=='') $error_message = _('The Claude API request failed.');
			throw new Exception($error_message);
		}

		return $data;
	}

	private function extract_output_text($response)
	{
		if(isset($response['stop_reason']) && $response['stop_reason']=='refusal')
			throw new Exception(_('Claude declined to generate this content.'));

		if(isset($response['content']) && is_array($response['content']))
		{
			$text = '';

			foreach($response['content'] as $block)
			{
				if(isset($block['type']) && $block['type']=='text' && isset($block['text']))
					$text .= $block['text'];
			}

			$text = trim($text);
			if($text!='') return $text;
		}

		throw new Exception(_('Claude returned an unexpected response.'));
	}

	private function extract_error_message($data)
	{
		if(isset($data['error']) && is_array($data['error']) && isset($data['error']['message']))
			return trim($data['error']['message']);

		if(isset($data['error']) && is_string($data['error']))
			return trim($data['error']);

		return '';
	}
}

?>
