<?php

// A URL fetch must never be sufficient to complete a double opt-out request.
// These tokens are kept separate from Sendy's normal logged-in session.
function sendy_unsubscribe_confirmation_start_session()
{
    if (session_status() === PHP_SESSION_ACTIVE) return true;

    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_name('SENDY_UNSUBSCRIBE');
    return session_start(array(
        'use_strict_mode' => 1,
        'use_only_cookies' => 1,
        'cookie_httponly' => true,
        'cookie_secure' => $secure,
        'cookie_samesite' => 'Lax'
    ));
}

function sendy_unsubscribe_confirmation_issue($target)
{
    if (!sendy_unsubscribe_confirmation_start_session()) return false;

    $token = bin2hex(random_bytes(32));
    $_SESSION['sendy_unsubscribe_confirmation'] = array(
        'token' => $token,
        'target' => $target,
        'expires' => time() + 600
    );
    session_write_close();
    return $token;
}

function sendy_unsubscribe_confirmation_verify($target)
{
    $token = isset($_POST['sendy_unsubscribe_confirmation']) ? $_POST['sendy_unsubscribe_confirmation'] : null;
    if (!is_string($token) || !sendy_unsubscribe_confirmation_start_session()) return false;

    $confirmation = isset($_SESSION['sendy_unsubscribe_confirmation'])
        ? $_SESSION['sendy_unsubscribe_confirmation'] : null;

    // Consume the token before returning so it cannot be replayed, including
    // when the target or expiry check fails.
    unset($_SESSION['sendy_unsubscribe_confirmation']);
    session_write_close();

    return is_array($confirmation)
        && isset($confirmation['token'], $confirmation['target'], $confirmation['expires'])
        && is_string($confirmation['token'])
        && is_string($confirmation['target'])
        && $confirmation['expires'] >= time()
        && hash_equals($confirmation['token'], $token)
        && hash_equals($confirmation['target'], $target);
}
