<?php

class AmazonSES
{
	public $Multithread = false;
	public $CampaignID	= 0;
	public $SubscriberID = 0;
	public $Timezone = '';
	public $SendRate = 0;
	public $IsAutoresponder = false;

    public $amazonSES_base_url = '';
    public $debug = FALSE;

    public $aws_access_key_id = "";
    public $aws_secret_key = "";

    private $_region;
    private $_host;
    private $_endpoint;
    private $_amz_date;
    private $_date;
    private $_method;

	    protected function
	    make_required_http_headers ($query = array()) {
	        if($this->Timezone=='' || $this->Timezone==0) $this->Timezone = date_default_timezone_get();
			date_default_timezone_set($this->Timezone);

	        $this->_generateSignature($query);

		$headers = array();
		$headers[] = 'Authorization: '.$this->_headers['Authorization'];
		$headers[] = 'content-type: application/x-www-form-urlencoded';
		$headers[] = 'host: '.$this->_host;
		$headers[] = 'x-amz-date: '.$this->_headers['x-amz-date'];

	        return $headers;
	    }

	    public function
	    make_required_http_headers_for_query_string ($query_str) {
	        if($this->Timezone=='' || $this->Timezone==0) $this->Timezone = date_default_timezone_get();
			date_default_timezone_set($this->Timezone);

			$this->_refreshDate();

			//Get region from host, eg. 'us-east-1'
			$region_explode = explode('.', $this->amazonSES_base_url);
			$region = $region_explode[1];
			$this->_region = $region;
			$content_type = 'content-type:application/x-www-form-urlencoded';
			$this->_method = 'POST';
			$this->_headers = array();

	        $canonical_uri = '/';
			$this->_host = 'email' . '.' . $this->_region . '.' . 'amazonaws.com';
			$this->amazonSES_base_url = 'https://' . 'email' . '.' . $this->_region . '.' . 'amazonaws.com';

	        $canonical_headers = $content_type . "\n" . 'host:' . $this->_host . "\n" . 'x-amz-date:' . $this->_amz_date . "\n";
	        $signed_headers = 'content-type;host;x-amz-date';
	        $payload_hash = hash('sha256', $query_str);
	        $canonical_request = $this->_method . "\n" . $canonical_uri . "\n" . '' . "\n" . $canonical_headers . "\n" . $signed_headers . "\n" . $payload_hash;
	        $credential_scope = $this->_date . '/' . $this->_region . '/' . 'email' . '/aws4_request';
	        $string_to_sign =  'AWS4-HMAC-SHA256' . "\n" . $this->_amz_date . "\n" . $credential_scope . "\n" . hash('sha256', $canonical_request);
	        $signing_key = $this->_generateSignatureKey();
	        $signature = hash_hmac('sha256', $string_to_sign, $signing_key);

	        $headers = array();
	        $headers[] = 'Authorization: AWS4-HMAC-SHA256 Credential=' . $this->aws_access_key_id . '/' . $credential_scope . ', SignedHeaders=' . $signed_headers . ', Signature=' . $signature;
			$headers[] = 'content-type: application/x-www-form-urlencoded';
			$headers[] = 'host: '.$this->_host;
			$headers[] = 'x-amz-date: '.$this->_amz_date;

	        return $headers;
	    }

    /**
     * Create and returns binary hmac sha256
     *
     * @return hmac sha256.
     */
    private function _generateSignatureKey()
    {
        $date_h = hash_hmac('sha256', $this->_date, 'AWS4' . $this->aws_secret_key, true);
        $region_h = hash_hmac('sha256', $this->_region, $date_h, true);
        $service_h = hash_hmac('sha256', 'email', $region_h, true);
        $signing_h = hash_hmac('sha256', 'aws4_request', $service_h, true);

        return $signing_h;
    }

	/**
     *  Refresh amzdate and date
     *
     *  @return void
     */
    private function _refreshDate()
    {
        $this->_amz_date = gmdate('Ymd\THis\Z');
        $this->_date = gmdate('Ymd');
    }

	private function _generateSignature($parameters = array()) {

		$this->_refreshDate();

		//Get region from host, eg. 'us-east-1'
		$region_explode = explode('.', $this->amazonSES_base_url);
		$region = $region_explode[1];
		$this->_region = $region;
		$content_type = 'content-type:application/x-www-form-urlencoded';

		//Request method
		$this->_method = 'POST';

		//Headers to pass to API
		$this->_headers = array();

        $canonical_uri = '/';

		//eg 'Action' => 'GetSendQuota';
        ksort($parameters);

		//Build parameters to send to API
        $request_parameters = http_build_query($parameters, '', '&');

		$this->_host = 'email' . '.' . $this->_region . '.' . 'amazonaws.com';
		$this->amazonSES_base_url = 'https://' . 'email' . '.' . $this->_region . '.' . 'amazonaws.com';

        $canonical_headers = $content_type . "\n" . 'host:' . $this->_host . "\n" . 'x-amz-date:' . $this->_amz_date . "\n";
        $signed_headers = 'content-type;host;x-amz-date';
        $payload_hash = hash('sha256', $request_parameters);

        // task1
        $canonical_request = $this->_method . "\n" . $canonical_uri . "\n" . '' . "\n" . $canonical_headers . "\n" . $signed_headers . "\n" . $payload_hash;

        // task2
        $credential_scope = $this->_date . '/' . $this->_region . '/' . 'email' . '/aws4_request';
        $string_to_sign =  'AWS4-HMAC-SHA256' . "\n" . $this->_amz_date . "\n" . $credential_scope . "\n" . hash('sha256', $canonical_request);

        // task3
        $signing_key = $this->_generateSignatureKey();
        $signature = hash_hmac('sha256', $string_to_sign, $signing_key);
        $this->_headers['Authorization'] = 'AWS4-HMAC-SHA256' . ' Credential=' . $this->aws_access_key_id . '/' . $credential_scope . ', SignedHeaders=' . $signed_headers . ', Signature=' . $signature;
        $this->_headers['x-amz-date'] = $this->_amz_date;
	}

    protected function
    make_query_string
    ($query) {
        $query_str = "";
        foreach ($query as $k => $v)
            { $query_str .= urlencode($k)."=".urlencode($v).'&'; }

        return rtrim($query_str, '&');
    }

    protected function
    parse_amazonSES_error
    ($response) {
        $sxe = simplexml_load_string($response);

        // If the error response can not be parsed properly,
        // then just return the original response content.
        if (($sxe === FALSE) or ($sxe->getName() !== "ErrorResponse"))
            { return $response; }

        return "{$sxe->Error->Code}"
               .(($sxe->Error->Message)?" - {$sxe->Error->Message}":"");
    }

    protected function
    make_request
    ($query) {
	    error_reporting(0);
	$dbHost=$dbUser=$dbPass=$dbName='';
		if(file_exists('../config.php')) require '../config.php';
		$server_path_array1 = explode('/', $_SERVER['SCRIPT_FILENAME']);
		$delimiter = $server_path_array1[count($server_path_array1)-1];
		if($delimiter=='send-now.php') $delimiter = 'includes';
		$server_path_array = explode($delimiter, $_SERVER['SCRIPT_FILENAME']);
		$server_path = $server_path_array[0];
		if(file_exists($server_path.'includes/config.php')) require $server_path.'includes/config.php';

		//Reuse the caller's existing database connection when it's live, instead of
		//opening a new one on every single message. A fresh connection per recipient
		//exhausts hosts that cap concurrent connections after a couple dozen sends,
		//and the resulting fatal is invisible because of the error_reporting(0)
		//above. scheduled.php, send-now.php and test-send.php all expose their
		//connection as $mysqli at top-level script scope (see scheduled.php's
		//dbConnect()), so it's reliably reachable here as $GLOBALS['mysqli'].
		$mysqli = null;
		if(isset($GLOBALS['mysqli']) && $GLOBALS['mysqli'] instanceof mysqli)
		{
			$probe = @mysqli_query($GLOBALS['mysqli'], 'SELECT 1');
			if($probe !== false) $mysqli = $GLOBALS['mysqli'];
		}
		if($mysqli === null)
		{
			if(isset($dbPort)) $mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName, $dbPort);
			else $mysqli = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
			if($mysqli->connect_error)
			{
				//Fail gracefully instead of falling through to query a connection
				//that PHP 8 will treat as already closed, which raises an uncaught
				//Error and kills the campaign with zero mail sent and no log entry.
				error_log('[Amazon SES] Unable to connect to the database: '.$mysqli->connect_error);
				return array('0', 'Unable to connect to the database', 'full_error' => 'Unable to connect to the database: '.$mysqli->connect_error);
			}
		}
		$db_context = new stdClass();
		$db_context->mysqli = $mysqli;
		$db_context->host = $dbHost;
		$db_context->user = $dbUser;
		$db_context->pass = $dbPass;
		$db_context->name = $dbName;
		$db_context->port = isset($dbPort) ? $dbPort : null;

		//Get SES endpoint
		$q = 'SELECT ses_endpoint FROM login LIMIT 1';
		$r = mysqli_query($mysqli, $q);
		if ($r) while($row = mysqli_fetch_array($r)) $this->amazonSES_base_url = 'https://'.$row['ses_endpoint'];

	        // Prepare headers and query string.
	        $query_str = $this->make_query_string($query);
	        $request_url = $this->amazonSES_base_url;
	        $http_headers = $this->Multithread ? array() : $this->make_required_http_headers($query);

        if ($this->debug) {
            echo "<pre>[AmazonSESDebug] Query Parameters:\n\"";
            print_r($query);
            echo "\"\n";

            printf("[AmazonSES Debug] Http Headers:\n\"%s\"\n",
                                      implode("\n", $http_headers));
            printf("[AmazonSES Debug] Query String:\n\"%s\"\n", $query_str);
            echo "</pre>";
        }

        //if multithreading is needed,
        if($this->Multithread)
        {
	        //Insert SES query into queue
	        $query_str_escaped = mysqli_real_escape_string($mysqli, $query_str);
		        $http_headers_escaped = '';
	        $q = 'INSERT IGNORE INTO queue (query_str, http_headers, campaign_id, subscriber_id)
				  VALUES ("'.$query_str_escaped.'", "'.$http_headers_escaped.'", '.$this->CampaignID.', '.$this->SubscriberID.')';
	        mysqli_query($mysqli, $q);
	        if(mysqli_affected_rows($mysqli) > 0)
	        {
		        $q4 = 'UPDATE subscribers SET last_campaign = '.$this->CampaignID.' WHERE id = '.$this->SubscriberID; //Update last_campaign in subscribers table
				mysqli_query($mysqli, $q4);
	        }

	        //Check if there are more than X (where X is the send rate) emails in queue, send them in parallel to SES
	        $q2 = 'SELECT id, query_str, http_headers, subscriber_id FROM queue FORCE INDEX (q_campaign_sent_id) WHERE campaign_id = '.$this->CampaignID.' AND sent = 0 ORDER BY id ASC LIMIT '.$this->SendRate;
	        $r2 = mysqli_query($mysqli, $q2);
	        if ($r2 && mysqli_num_rows($r2) >= $this->SendRate)
	        {
		        $batch_rows = array();
		        $id_array = array();
		        while($row = mysqli_fetch_array($r2))
		        {
				$batch_rows[] = $row;
				$id_array[] = (int)$row['id'];
		        }

		        //Durably claim the batch before handing it to SES. A value of 2
		        //means delivery is in flight and must never be retried automatically.
		        $claim_query = 'UPDATE queue SET sent = 2 WHERE sent = 0 AND id IN ('.implode(',', $id_array).')';
		        $claim_result = mysqli_query($mysqli, $claim_query);
		        if(!$claim_result || mysqli_affected_rows($mysqli) != count($id_array))
		        {
				$GLOBALS['sendy_ses_fatal_error'] = 'Unable to claim the Amazon SES delivery batch in the database.';
				mysqli_query($mysqli, 'UPDATE campaigns SET send_status = "interrupted", send_error = "Unable to claim the Amazon SES delivery batch in the database." WHERE id = '.(int)$this->CampaignID);
				error_log('[Amazon SES sending interrupted] Campaign '.(int)$this->CampaignID.': unable to claim queue batch');
				return array('0', 'Unable to claim Amazon SES queue batch', 'full_error' => $GLOBALS['sendy_ses_fatal_error']);
		        }

		        $time_started = microtime(true);

		        if (!function_exists('on_request_done'))
				{
						function sendy_ses_db_reconnect($db_context)
						{
							if($db_context->port !== null)
								$db_context->mysqli = new mysqli($db_context->host, $db_context->user, $db_context->pass, $db_context->name, $db_context->port);
							else
								$db_context->mysqli = new mysqli($db_context->host, $db_context->user, $db_context->pass, $db_context->name);
							return !$db_context->mysqli->connect_error;
						}

						function sendy_ses_db_query($db_context, $query)
						{
							$result = mysqli_query($db_context->mysqli, $query);
							if($result !== false) return $result;
							if(!sendy_ses_db_reconnect($db_context)) return false;
							return mysqli_query($db_context->mysqli, $query);
						}

						function sendy_ses_interrupt_campaign($db_context, $campaign_id, $message)
						{
							$GLOBALS['sendy_ses_fatal_error'] = $message;
							if(sendy_ses_db_reconnect($db_context))
							{
								$message_escaped = mysqli_real_escape_string($db_context->mysqli, $message);
								mysqli_query($db_context->mysqli, 'UPDATE campaigns SET send_status = "interrupted", send_error = "'.$message_escaped.'" WHERE id = '.(int)$campaign_id);
							}
							error_log('[Amazon SES sending interrupted] Campaign '.(int)$campaign_id.': '.$message);
							return false;
						}

							function sendy_ses_record_delivery_failure($db_context, $queue_id, $campaign_id, $subscriber_id, $http_status_code)
							{
								$error_entry = (int)$subscriber_id.':'.(int)$http_status_code;
								$error_exists = false;
								$errors = '';
								$error_result = sendy_ses_db_query($db_context, 'SELECT errors FROM campaigns WHERE id = '.(int)$campaign_id);
								if($error_result && $error_row = mysqli_fetch_array($error_result))
								{
									$errors = (string)$error_row['errors'];
									$error_exists = in_array($error_entry, array_filter(explode(',', $errors)), true);
								}

								//A repeated HTTP 400 is a permanent request/recipient failure.
								//Resolve it after one retry so it cannot block the queue forever.
								if((int)$http_status_code === 400 && $error_exists)
								{
									if(!(function_exists('mysqli_begin_transaction') ? mysqli_begin_transaction($db_context->mysqli) : mysqli_query($db_context->mysqli, 'START TRANSACTION'))) return false;
									$queue_result = mysqli_query($db_context->mysqli, 'UPDATE queue SET sent = 1, query_str = NULL, http_headers = NULL WHERE id = '.(int)$queue_id.' AND sent = 2');
									$campaign_result = $queue_result && mysqli_affected_rows($db_context->mysqli) === 1
										? mysqli_query($db_context->mysqli, 'UPDATE campaigns SET recipients = recipients+1, timeout_check = NULL WHERE recipients < to_send AND id = '.(int)$campaign_id)
										: false;
									if($campaign_result && mysqli_affected_rows($db_context->mysqli) === 1 && mysqli_commit($db_context->mysqli)) return true;
									mysqli_rollback($db_context->mysqli);
									return false;
								}

								if(sendy_ses_db_query($db_context, 'UPDATE queue SET sent = 0 WHERE id = '.(int)$queue_id.' AND sent = 2') === false) return false;
								if(!$error_exists)
								{
									$errors = $errors==='' ? $error_entry : $errors.','.$error_entry;
									$errors = mysqli_real_escape_string($db_context->mysqli, $errors);
									if(sendy_ses_db_query($db_context, 'UPDATE campaigns SET errors = "'.$errors.'" WHERE id = '.(int)$campaign_id) === false) return false;
								}
								return true;
							}

						function sendy_ses_acknowledge_delivery($db_context, $queue_id, $campaign_id, $subscriber_id, $message_id)
						{
							for($attempt=0; $attempt<2; $attempt++)
							{
								if($attempt > 0 && !sendy_ses_db_reconnect($db_context)) continue;
								if(!(function_exists('mysqli_begin_transaction') ? mysqli_begin_transaction($db_context->mysqli) : mysqli_query($db_context->mysqli, 'START TRANSACTION'))) continue;

								$queue_result = mysqli_query($db_context->mysqli, 'UPDATE queue SET sent = 1, query_str = NULL, http_headers = NULL WHERE id = '.(int)$queue_id.' AND sent = 2');
								$queue_affected = $queue_result ? mysqli_affected_rows($db_context->mysqli) : -1;
								if($queue_result && $queue_affected === 0)
								{
									$confirm = mysqli_query($db_context->mysqli, 'SELECT sent FROM queue WHERE id = '.(int)$queue_id.' LIMIT 1');
									if($confirm && $confirm_row = mysqli_fetch_array($confirm))
									{
										if((int)$confirm_row['sent'] === 1)
										{
											mysqli_rollback($db_context->mysqli);
											return true;
										}
									}
								}
								if(!$queue_result || $queue_affected !== 1)
								{
									mysqli_rollback($db_context->mysqli);
									continue;
								}

								$campaign_result = mysqli_query($db_context->mysqli, 'UPDATE campaigns SET recipients = recipients+1, timeout_check = NULL WHERE recipients < to_send AND id = '.(int)$campaign_id);
								if(!$campaign_result || mysqli_affected_rows($db_context->mysqli) !== 1)
								{
									mysqli_rollback($db_context->mysqli);
									continue;
								}

								$message_id_escaped = mysqli_real_escape_string($db_context->mysqli, $message_id);
								$subscriber_result = mysqli_query($db_context->mysqli, 'UPDATE subscribers SET messageID = "'.$message_id_escaped.'" WHERE id = '.(int)$subscriber_id);
								if(!$subscriber_result)
								{
									mysqli_rollback($db_context->mysqli);
									continue;
								}

								if(mysqli_commit($db_context->mysqli)) return true;
							}
							return false;
						}

						function on_request_done($content, $url, $ch, $callback_data)
						{
							$db_context = $callback_data[6];
							$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
						    if ($httpcode === 200) //if success
						    {
							$messageIDArray = explode('<MessageId>', $content);
						        $messageIDArray2 = isset($messageIDArray[1]) ? explode('</MessageId>', $messageIDArray[1]) : array('');
						        $subscriber_id = (int)$callback_data[0];
						        $campaign_id = (int)$callback_data[4];
						        $queue_id = (int)$callback_data[5];

						        if(!sendy_ses_acknowledge_delivery($db_context, $queue_id, $campaign_id, $subscriber_id, $messageIDArray2[0]))
								return sendy_ses_interrupt_campaign($db_context, $campaign_id, 'SES accepted a message, but Sendy could not record its queue acknowledgement.');
								return true;
						    }
						    else //if fail
						    {
						        $response_http_status_code = (int)$httpcode;
						        $response_http_status_code = $response_http_status_code === 0 ? curl_errno($ch) : $response_http_status_code;
						        $campaign_id = (int)$callback_data[4];
						        $val = $callback_data[0].':'.$response_http_status_code;

							        $queue_id = (int)$callback_data[5];
									if(!sendy_ses_record_delivery_failure($db_context, $queue_id, $campaign_id, (int)$callback_data[0], $response_http_status_code))
										return sendy_ses_interrupt_campaign($db_context, $campaign_id, 'Sendy could not safely record an Amazon SES delivery failure.');
									return true;
						    }
						}
					}

		        $mh = curl_multi_init();
		        $outstanding_requests = array();

	            foreach($batch_rows as $row)
	            {
				$queue_id = $row['id'];
				$queue = stripslashes((string)$row['query_str']);
				$http_headers = $this->make_required_http_headers_for_query_string($queue);
				$subscriber_id = $row['subscriber_id'];
				// Prepare curl.
			        $ch = curl_init();
			        curl_setopt($ch, CURLOPT_URL, $request_url);
			        curl_setopt($ch, CURLOPT_POST, $queue);
			        curl_setopt($ch, CURLOPT_POSTFIELDS, $queue);
			        curl_setopt($ch, CURLOPT_HTTPHEADER, $http_headers);
			        curl_setopt($ch, CURLOPT_HEADER, true);
			        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
					curl_setopt($ch, CURLOPT_CAINFO, $server_path.'certs/cacert.pem');
					//Single bounded SES API call - fail fast rather than hang the batch.
					curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
					curl_setopt($ch, CURLOPT_TIMEOUT, 30);


			        //add handle
					curl_multi_add_handle($mh, $ch);

					$ch_array_key = (int)$ch;

				        $outstanding_requests[$ch_array_key] = array(
				            'url' => $request_url,
				            'callback' => 'on_request_done',
				            'user_data' => array($subscriber_id, $queue, $request_url, $http_headers, $this->CampaignID, $queue_id, $db_context)
				        );
	            }

					//execute the handles
					$active = null;
				do
				{
				    $mrc = curl_multi_exec($mh, $active);
				    while ($info=curl_multi_info_read($mh))
		            {
			$ch = $info['handle'];
			            $ch_array_key = (int)$ch;

			            $request = $outstanding_requests[$ch_array_key];

			            $url = $request['url'];
			            $content = curl_multi_getcontent($ch);
			            $callback = $request['callback'];
			            $user_data = $request['user_data'];

				            $callback_result = call_user_func($callback, $content, $url, $ch, $user_data);
				            if($callback_result === false) $active = 0;

			            unset($outstanding_requests[$ch_array_key]);

			            curl_multi_remove_handle($mh, $ch);
					    }
					    if($active && $mrc == CURLM_OK)
					    {
						$selected = curl_multi_select($mh, 0.2);
						if($selected === -1) usleep(10000);
					    }
				} while ($mrc == CURLM_CALL_MULTI_PERFORM || ($active && $mrc == CURLM_OK));

				curl_multi_close($mh);

					//throttling
				$time_taken = microtime(true) - $time_started;
				$usleep = ceil((1 - $time_taken) * 1000000);
				if($time_taken < 1) usleep($usleep);
	        }
        }

        else
        {
	//Get server path
	$server_path_array2 = explode('includes/', $_SERVER['SCRIPT_FILENAME']);
		    $server_path2 = $server_path_array2[0];
		    if(count($server_path_array2)==1) $server_path2 = $server_path;

	        // Prepare curl.
	        $cr = curl_init();
	        curl_setopt($cr, CURLOPT_URL, $request_url);
	        curl_setopt($cr, CURLOPT_POST, $query_str);
	        curl_setopt($cr, CURLOPT_POSTFIELDS, $query_str);
	        curl_setopt($cr, CURLOPT_HTTPHEADER, $http_headers);
	        curl_setopt($cr, CURLOPT_HEADER, true);
	        curl_setopt($cr, CURLOPT_RETURNTRANSFER, true);
	        curl_setopt($cr, CURLOPT_SSL_VERIFYHOST, 2);
			curl_setopt($cr, CURLOPT_SSL_VERIFYPEER, 1);
			curl_setopt($cr, CURLOPT_CAINFO, $server_path2.'certs/cacert.pem');
			//Single bounded SES API call - fail fast rather than hang the send.
			curl_setopt($cr, CURLOPT_CONNECTTIMEOUT, 10);
			curl_setopt($cr, CURLOPT_TIMEOUT, 30);

		        // Make the request and fetch response.
		        $response = curl_exec($cr);
		        $response_http_status_code = curl_getinfo($cr, CURLINFO_HTTP_CODE);

		        // Separate header and content.
		        $tmpar = explode("\r\n\r\n", $response, 2);
		        $response_http_headers = $tmpar[0];
		        $response_content = isset($tmpar[1]) ? $tmpar[1] : '';

		        if($response_http_status_code != 200)
		        {
			        //Response title
			        $response_title_array1 = explode('<Code>', $response_content);
			        $response_title_array2 = isset($response_title_array1[1]) ? explode('</Code>', $response_title_array1[1]) : array('');
			        $response_title = $response_title_array2[0];

			        //Response message
			        $response_msg_array1 = explode('<Message>', $response_content);
			        $response_msg_array2 = isset($response_msg_array1[1]) ? explode('</Message>', $response_msg_array1[1]) : array(curl_error($cr));
			        $response_msg = $response_msg_array2[0];

			        //Response requestID
			        $response_rqid_array1 = explode('<RequestId>', $response_content);
			        $response_rqid_array2 = isset($response_rqid_array1[1]) ? explode('</RequestId>', $response_rqid_array1[1]) : array('');
			        $response_rqid = $response_rqid_array2[0];

			        $the_error = array();
			        $the_error[0] = (string)$response_http_status_code;
			        $the_error['code'] = $response_http_status_code;
			        $the_error['full_error'] = $response_title.' (Request ID: '.$response_rqid.'): '.$response_msg;

			        //Write to error_log
			        error_log($the_error['full_error']);

			        if($this->CampaignID != '' && $this->SubscriberID != '')
			        {
				$q7 = 'SELECT errors FROM campaigns WHERE id = '.$this->CampaignID;
				$r7 = mysqli_query($mysqli, $q7);
				$val = $this->SubscriberID.':'.$response_http_status_code;
				if ($r7)
				{
				    while($row = mysqli_fetch_array($r7))
				    {
						$errors = $row['errors'];
						if($errors!='') $val = $errors.','.$val;
				    }
				}
				$val = mysqli_real_escape_string($mysqli, $val);
				        $q6 = 'UPDATE campaigns SET errors = "'.$val.'" WHERE id = '.$this->CampaignID;
						mysqli_query($mysqli, $q6);
			        }

			        return $the_error;
				}

	        //Check if there's a campaign/autoresponder ID
	        if($this->CampaignID != '')
	        {
		//Get message ID from response
		        $messageIDArray = explode('<MessageId>', $response);
		        $messageIDArray2 = explode('</MessageId>', $messageIDArray[1]);
		        $messageID = $messageIDArray2[0];

		        //Update subscriber's messageID if it's an Autoresponder
		        if($this->IsAutoresponder)
		        {
			        $q9 = 'UPDATE subscribers SET messageID = "'.$messageID.'" WHERE id = '.$this->SubscriberID;
			mysqli_query($mysqli, $q9);
		        }
		        //Increment recipients number in campaigns table if it's a campaign
		else
		{
					$q5 = 'UPDATE campaigns SET recipients = recipients+1 WHERE id = '.$this->CampaignID;
					$q9 = 'UPDATE subscribers SET last_campaign = '.$this->CampaignID.', messageID = "'.$messageID.'" WHERE id = '.$this->SubscriberID;
					mysqli_query($mysqli, $q5);
					mysqli_query($mysqli, $q9);
			        }
				}

			//Return the successful HTTP result to PHPMailer. AmazonSESSend()
			//expects the documented array(status code, response content), but
			//this synchronous path previously fell through and returned NULL.
			return array((string)$response_http_status_code, $response_content);
		}
	    }

    //***********************************************************************
    // Name: send_mail
    // Description:
    //    Send mail using amazonSES. Provide $header, $subject,
    //    $body appropriately. The $recipients and $from are mostly expe-
    //    rimental and unneccessary as documented in the SES api.
    //
    //    Return an array in the form -
    //        array(http_status_code, response_content)
    //    if the http_status_code is something other than "200", then
    //    the response_content is an error message parsed from the response.
    //***********************************************************************

    public function
    send_mail
    ($header, $subject, $body,
     $recipients=FALSE, $from=FALSE) {
        // Make sure that there is a blank line between header and body.
        $raw_mail = rtrim($header, "\r\n")."\n\n".$body;

        // Prepare query.
        //*********************************************************//
        $query = array();
        $query["Action"] = "SendRawEmail";

        // Add optional Destination.member.N request parameter.
        if ($recipients) {
            $mcnt = 1;
            foreach ($recipients as $recipient) {
                $query["Destinations.member.{$mcnt}"] = $recipient;
                $mcnt += 1;
            }
        }

        // Add mail data.
        $query["RawMessage.Data"] = base64_encode($raw_mail);
        //*********************************************************//

        // Send the mail and forward the result array to the caller.
        return $this->make_request($query);
    }

    public function
    request_verification
    ($email_address) {
        $query = array();

        $query["Action"] = "VerifyEmailAddress";
        $query["EmailAddress"] = $email_address;
        $query["X-Amz-Expires"] = 604800;

        return $this->make_request($query);
    }
}

/* End of file */
