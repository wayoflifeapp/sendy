<?php
//Get API key
$q_api = 'SELECT api_key FROM login ORDER BY id ASC LIMIT 1';
$r_api = mysqli_query($mysqli, $q_api);
if ($r_api) while($row = mysqli_fetch_array($r_api)) define('API_KEY', $row['api_key']);

//Encryption method
$encryptionMethod = "AES-256-CBC";

//Encrypt a value
function encrypt_val($val)
{
	global $encryptionMethod;
	if(version_compare(PHP_VERSION, '5.3.0') >= 0 && function_exists('openssl_encrypt')) //openssl_encrypt requires at least 5.3.0
	{
		$encrypted = version_compare(PHP_VERSION, '5.3.3') >= 0 ? openssl_encrypt($val, $encryptionMethod, API_KEY, 0, '3j9hwG7uj8uvpRAT') : openssl_encrypt($val, $encryptionMethod, API_KEY, 0);
		if(!$encrypted) 
		{
			$error = 'Unable to encrypt string with openssl_encrypt()';
			error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
			echo $error;
			exit;
		}
		
		$encrypted = str_replace('/', '892', $encrypted);
		$encrypted = str_replace('+', '763', $encrypted);
		$encrypted = str_replace('=', '', $encrypted);
		
		return $encrypted;
	}
	else
	{
		$error = 'Unable to use openssl_encrypt() because PHP version is lower than 5.3 and openssl_encrypt() does not exist';
		error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
		echo $error;
		exit;
	}
}

//Decrypt a string
function decrypt_string($val)
{
	global $encryptionMethod;
	
	if(version_compare(PHP_VERSION, '5.3.0') >= 0 && function_exists('openssl_decrypt')) //openssl_decrypt requires at least 5.3.0
	{
		$decrypted = decrypt_url_safe($val, 'is_plausible_string');
		if(!$decrypted)
		{
			if(!empty($decrypted))
			{
				$error = 'Unable to decrypt string with openssl_decrypt()';
				error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
				echo $error;
				exit;
			}
		}
		
		return $decrypted;
	}
	else
	{
		$error = 'Unable to use openssl_decrypt() because PHP version is lower than 5.3 and openssl_decrypt() does not exist';
		error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
		echo $error;
		exit;
	}
}

//Decrypt an integer
function decrypt_int($in)
{
	global $encryptionMethod;

	if(version_compare(PHP_VERSION, '5.3.0') >= 0 && function_exists('openssl_decrypt')) //openssl_decrypt requires at least 5.3.0
	{
		$decrypted = decrypt_url_safe($in, 'is_plausible_int');
		if($decrypted === false || !is_numeric($decrypted))
		{
			if(!empty($decrypted))
			{
				$error = 'Unable to decrypt string with openssl_decrypt()';
				error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
				echo $error;
				exit;
			}
		}

		return (int) $decrypted;
	}
	else
	{
		$error = 'Unable to use openssl_decrypt() because PHP version is lower than 5.3 and openssl_decrypt() does not exist';
		error_log("[$error]".': in '.__FILE__.' on line '.__LINE__);
		echo $error;
		exit;
	}
}

//Decrypt a value made URL-safe by encrypt_val().
//encrypt_val() writes '/' as '892' and '+' as '763', but those digits can also occur naturally in the
//ciphertext, so decoding every occurrence corrupts it. Try that first (it is right almost always), and
//if the result isn't plausible, retry with some occurrences kept as literal digits, fewest first.
function decrypt_url_safe($val, $is_plausible)
{
	global $encryptionMethod;
	
	$parts = preg_split('/(892|763)/', (string) $val, -1, PREG_SPLIT_DELIM_CAPTURE);
	$count = (count($parts) - 1) / 2;
	$first = null;
	$attempts = 0;
	
	for($keep = 0; $keep <= $count; $keep++)
	{
		//Walk every combination of $keep occurrences (by index) to leave as literal digits
		$combo = $keep ? range(0, $keep - 1) : array();
		while(true)
		{
			$candidate = '';
			foreach($parts as $i => $part)
			{
				if($i % 2 == 0) $candidate .= $part;
				else $candidate .= in_array(($i - 1) / 2, $combo) ? $part : ($part == '892' ? '/' : '+');
			}
			
			$decrypted = version_compare(PHP_VERSION, '5.3.3') >= 0 ? openssl_decrypt($candidate, $encryptionMethod, API_KEY, 0, '3j9hwG7uj8uvpRAT') : openssl_decrypt($candidate, $encryptionMethod, API_KEY, 0);
			if($first === null) $first = $decrypted;
			if($is_plausible($decrypted)) return $decrypted;
			if(++$attempts >= 1024) return $first;
			
			//Advance to the next combination
			$i = $keep - 1;
			while($i >= 0 && $combo[$i] == $count - $keep + $i) $i--;
			if($i < 0) break;
			$combo[$i]++;
			for($j = $i + 1; $j < $keep; $j++) $combo[$j] = $combo[$j - 1] + 1;
		}
	}
	
	return $first;
}

//A correctly decrypted integer is all digits
function is_plausible_int($decrypted)
{
	return $decrypted !== false && preg_match('/^[0-9]+$/', $decrypted);
}

//A wrongly decoded ciphertext decrypts to false or random bytes, not clean text
function is_plausible_string($decrypted)
{
	return $decrypted !== false && $decrypted !== '' && preg_match('//u', $decrypted) && !preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', $decrypted);
}
?>