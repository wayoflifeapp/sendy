<?php

require_once(dirname(__FILE__).'/openai.php');
require_once(dirname(__FILE__).'/claude.php');

function sendy_create_ai_client($provider, $api_key, $options = array())
{
	if(sendy_normalize_ai_provider($provider)=='claude')
		return new SendyClaudeAiClient($api_key, $options);

	return new SendyOpenAiClient($api_key, $options);
}

?>
