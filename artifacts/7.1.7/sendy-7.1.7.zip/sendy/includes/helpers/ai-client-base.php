<?php

abstract class SendyAiClientBase
{
	protected $api_key = '';
	protected $timeout = 45;
	protected $ca_cert_path = '';

	public function __construct($api_key, $options = array())
	{
		$this->api_key = trim((string)$api_key);
		$this->ca_cert_path = dirname(dirname(__DIR__)).'/certs/cacert.pem';

		if(isset($options['timeout']) && is_numeric($options['timeout']))
			$this->timeout = (int)$options['timeout'];
	}

	public function build_subject_source($html, $plain_text='')
	{
		$plain_text = $this->normalize_whitespace($plain_text);
		$html_text = $this->html_to_text($html);

		if($plain_text!='' && $html_text!='')
		{
			if($plain_text == $html_text) $content = $plain_text;
			else $content = "Plain text version:\n".$plain_text."\n\nHTML version:\n".$html_text;
		}
		else if($plain_text!='') $content = $plain_text;
		else $content = $html_text;

		return $this->limit_text($content, 12000);
	}

	public function get_subject_prompt_template($prompt_mode='compelling')
	{
		switch($prompt_mode)
		{
			case 'curiosity':
				return "Generate one curiosity-based email subject line for the following email.\n\nRequirements:\n- Plain text only.\n- One line only.\n- Create an open loop that makes the reader want to learn more.\n- Keep the curiosity specific to the email content.\n- Prefer roughly 40 to 70 characters when possible.\n- Do not use quotation marks.\n- Avoid misleading clickbait, emojis, spammy words, or all caps.\n\nCurrent subject draft (optional context): {{current_subject}}\n\nEmail content:\n{{email_content}}";

			case 'value':
				return "Generate one value-based email subject line for the following email.\n\nRequirements:\n- Plain text only.\n- One line only.\n- Lead with the concrete benefit, outcome, offer, or useful takeaway.\n- Keep it concise and specific.\n- Prefer roughly 40 to 70 characters when possible.\n- Do not use quotation marks.\n- Avoid vague claims, emojis, spammy words, or all caps.\n\nCurrent subject draft (optional context): {{current_subject}}\n\nEmail content:\n{{email_content}}";

			case 'personal':
				return "Generate one email subject line in a personal, conversational tone for the following email.\n\nRequirements:\n- Plain text only.\n- One line only.\n- Sound warm, direct, and human, like a note from one person to another.\n- Keep it natural and specific to the email content.\n- Prefer roughly 40 to 70 characters when possible.\n- Do not use quotation marks.\n- Avoid over-familiar language, emojis, spammy words, or all caps.\n\nCurrent subject draft (optional context): {{current_subject}}\n\nEmail content:\n{{email_content}}";

			case 'compelling':
			default:
				return "Generate one email subject line for the following email.\n\nRequirements:\n- Plain text only.\n- One line only.\n- Keep it concise and specific.\n- Prefer roughly 40 to 70 characters when possible.\n- Do not use quotation marks.\n- Avoid emojis unless the email clearly calls for them.\n- Avoid spammy words or clickbait.\n\nCurrent subject draft (optional context): {{current_subject}}\n\nEmail content:\n{{email_content}}";
		}
	}

	public function get_subject_context_template()
	{
		return "Current subject draft (optional context): {{current_subject}}\n\nEmail content:\n{{email_content}}";
	}

	protected function build_subject_prompt($content, $current_subject='', $prompt_mode='compelling', $custom_prompt='')
	{
		$current_subject = $this->sanitize_subject_line($current_subject);
		$template = trim($custom_prompt)!='' ? trim($custom_prompt) : $this->get_subject_prompt_template($prompt_mode);

		$prompt = str_replace(
			array('{{current_subject}}', '{{email_content}}'),
			array($current_subject, $content),
			$template
		);

		if(strpos($template, '{{email_content}}')===false)
		{
			$prompt .= "\n\n".str_replace(
				array('{{current_subject}}', '{{email_content}}'),
				array($current_subject, $content),
				$this->get_subject_context_template()
			);
		}

		return $prompt;
	}

	protected function html_to_text($html)
	{
		$html = (string)$html;
		if(trim($html)=='') return '';

		$html = preg_replace('/<script\b[^>]*>.*?<\/script>/is', ' ', $html);
		$html = preg_replace('/<style\b[^>]*>.*?<\/style>/is', ' ', $html);
		$html = preg_replace('/<head\b[^>]*>.*?<\/head>/is', ' ', $html);
		$html = str_ireplace(array('</p>', '</div>', '</li>', '<br>', '<br/>', '<br />', '</tr>', '</table>', '</h1>', '</h2>', '</h3>', '</h4>', '</h5>', '</h6>'), "\n", $html);
		$html = strip_tags($html);
		$html = html_entity_decode($html, ENT_QUOTES, 'UTF-8');

		return $this->normalize_whitespace($html);
	}

	protected function normalize_whitespace($text)
	{
		$text = html_entity_decode((string)$text, ENT_QUOTES, 'UTF-8');
		$text = str_replace(array("\r\n", "\r"), "\n", $text);
		$text = preg_replace("/\n{3,}/", "\n\n", $text);
		$text = preg_replace('/[ \t]+/', ' ', $text);
		$text = preg_replace('/[ ]*\n[ ]*/', "\n", $text);
		return trim($text);
	}

	protected function sanitize_subject_line($subject)
	{
		$subject = trim((string)$subject);
		$subject = str_replace(array("\r\n", "\r", "\n"), ' ', $subject);
		$subject = preg_replace('/^\s*(?:subject)\s*:\s*/i', '', $subject);
		$subject = preg_replace('/^\s*(?:[-*]\s+|\d+[\.\)]\s+)/', '', $subject);
		$subject = trim($subject, " \t\n\r\0\x0B\"'");
		$subject = preg_replace('/\s{2,}/', ' ', $subject);
		return $this->limit_text($subject, 255);
	}

	protected function strip_markdown_code_fence($text)
	{
		$text = trim((string)$text);

		if(preg_match('/^```(?:html)?\s*(.*?)\s*```$/is', $text, $matches))
			return trim($matches[1]);

		return $text;
	}

	protected function limit_text($text, $limit)
	{
		$text = trim((string)$text);
		if($text=='') return '';

		if(function_exists('mb_strlen') && function_exists('mb_substr'))
		{
			if(mb_strlen($text, 'UTF-8') > $limit)
				return trim(mb_substr($text, 0, $limit, 'UTF-8'));
		}
		else if(strlen($text) > $limit)
			return trim(substr($text, 0, $limit));

		return $text;
	}
}

?>
