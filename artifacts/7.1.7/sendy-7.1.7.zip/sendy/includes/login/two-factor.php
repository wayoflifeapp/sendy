<?php
//------------------------------------------------------//
//                          INIT                        //
//------------------------------------------------------//

include('../functions.php');
require_once('../helpers/two-factor/lib/otphp.php');

//Only reachable between a correct password (includes/login/main.php) and a correct OTP code
if(empty($_SESSION['otp_pending']) || !isset($_SESSION['userID']) || empty($_SESSION['auth_key']))
{
	header("Location: ".get_app_info('path').'/login');
	exit;
}

$totp_secret_key = $_SESSION['auth_key'];
$totp = new \OTPHP\TOTP($totp_secret_key);

$redirect = mysqli_real_escape_string($mysqli, $_POST['redirect']);

if(isset($redirect)) $redirect_to = $redirect;
else $redirect_to = '';

//Init OTP
$otp = $totp->now();

//Email of the account waiting for its OTP, failed codes count as failed logins for it
$otp_email = '';
if(isset($_SESSION['userID']))
{
	$r = mysqli_query($mysqli, 'SELECT username FROM login WHERE id = '.(int)$_SESSION['userID']);
	if($r && ($row = mysqli_fetch_array($r))) $otp_email = $row['username'];
}

//5 wrong codes per password entry, or the email/IP login limit, sends the user back to the login page
if(!isset($_SESSION['otp_failures'])) $_SESSION['otp_failures'] = 0;
if($_SESSION['otp_failures'] >= 5 || sendy_rate_limited('login', $otp_email, 10, 30, 900))
{
	unset($_SESSION['auth_key'], $_SESSION['otp_pending'], $_SESSION['userID'], $_SESSION['otp_failures']);
	header("Location: ".get_app_info('path').'/login?e=4');
	exit;
}

//Get POSTed OTP code from form
if(is_numeric($_POST['otp_code'])) $otp_code = $_POST['otp_code'];
else
{
	header("Location: ".get_app_info('path').'/two-factor?e=1&redirect='.$redirect_to);
	exit;
}

//If OTP code is correct
if($totp->verify($otp_code))
{
	unset($_SESSION['otp_failures'], $_SESSION['otp_pending']);
	sendy_rate_limit_clear('login', $otp_email);

	//set cookie and log in
	if(sendy_login_token_create($_SESSION['userID']))
	{
		if($redirect_to=='') header("Location: ../../");
		else header("Location: ../../".$redirect_to);
	}
}
else
{
	$_SESSION['otp_failures']++;
	sendy_rate_limit_record('login', $otp_email);

	//user doesn't exist and exit
	if($redirect_to=='') header("Location: ../../two-factor?e=2");
	else header("Location: ../../two-factor?e=2&redirect=".$redirect_to);
	exit;
}

?>