<?php
//------------------------------------------------------//
//                          INIT                        //
//------------------------------------------------------//

include('../functions.php');

$email = mysqli_real_escape_string($mysqli, $_POST['email']);
$pass = mysqli_real_escape_string($mysqli, $_POST['password']);
$pass_encrypted = hash('sha512', $pass.'PectGtma');
if(isset($_POST['redirect'])) $redirect_to = $_POST['redirect'];
else $redirect_to = '';
$time = time();
$app_id_line = null;

//------------------------------------------------------//
//                         EVENTS                       //
//------------------------------------------------------//
if($pass=='' || $email=='')
{
	//user doesn't exist and exit
	if($redirect_to=='') header("Location: ".get_app_info('path')."/login?e=1");
	else header("Location: ".get_app_info('path')."/login?e=1&redirect=$redirect_to");
	exit;
}
else
{
	//Too many failed attempts for this email (10) or IP (30) in the last 15 minutes
	if(sendy_rate_limited('login', $_POST['email'], 10, 30, 900))
	{
		if($redirect_to=='') header("Location: ".get_app_info('path')."/login?e=4");
		else header("Location: ".get_app_info('path')."/login?e=4&redirect=$redirect_to");
		exit;
	}

	//If logging in using brand's custom domain URL
	if(CURRENT_DOMAIN!=APP_PATH_DOMAIN)
	{
		//Get app id
		$q = 'SELECT id FROM apps WHERE custom_domain = "'.mysqli_real_escape_string($mysqli, CURRENT_DOMAIN).'"';
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0) while($row = mysqli_fetch_array($r)) $app_id = $row['id'];
		$app_id_line = !empty($app_id) ? 'AND app = '.$app_id : null;	
	}
	
	//Get login details
	$q = 'SELECT id, tied_to, app, auth_enabled, auth_key FROM login WHERE username = "'.$email.'" AND password = "'.$pass_encrypted.'" '.$app_id_line.' ORDER BY id ASC LIMIT 1';
	$r = mysqli_query($mysqli, $q);
	if ($r && mysqli_num_rows($r) > 0)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$userID = $row['id'];
			$tied_to = $row['tied_to'];
			$auth_enabled = $row['auth_enabled'];
			$_SESSION['auth_key'] = $row['auth_key'];
			$_SESSION['restricted_to_app'] = $row['app'];
			$_SESSION['userID'] = $userID;
	    }
	    
	    //Reset any pending password requests
		$q2 = 'UPDATE login SET reset_password_key = "" WHERE id = '.$userID;
		mysqli_query($mysqli, $q2);
		remember_login_email($email);

		//2FA users are only cleared once the OTP code is correct (includes/login/two-factor.php)
		$_SESSION['otp_failures'] = 0;
		if(!$auth_enabled) sendy_rate_limit_clear('login', $_POST['email']);

		//If 2FA enabled
		if($auth_enabled)
		{
			//two-factor.php creates the login token once the OTP code is correct
			$_SESSION['otp_pending'] = true;
			if($tied_to=='')
			{
				if($redirect_to=='') header("Location: ".get_app_info('path').'/two-factor');
				else header("Location: ".get_app_info('path').'/two-factor?redirect='.$redirect_to);
			}
			else
			{
				if($redirect_to=='') header("Location: ".get_app_info('path')."/two-factor?redirect=app?i=".$_SESSION['restricted_to_app']);
				else header("Location: ".get_app_info('path')."/two-factor?redirect=".$redirect_to);
			}
		}	
		//set cookie and log in
		else if(sendy_login_token_create($userID))
		{			
			if($tied_to=='')
			{
				if($redirect_to=='') header("Location: ".get_app_info('path'));
				else header("Location: ".get_app_info('path').'/'.$redirect_to);
			}
			else
			{
				if($redirect_to=='') header("Location: ".get_app_info('path')."/app?i=".$_SESSION['restricted_to_app']);
				else header("Location: ".get_app_info('path')."/".$redirect_to);
			}
		}
	}
	else
	{
		sendy_rate_limit_record('login', $_POST['email']);

		//user doesn't exist and exit
		if($redirect_to=='') header("Location: ".get_app_info('path')."/login?e=2");
		else header("Location: ".get_app_info('path')."/login?e=2&redirect=$redirect_to");
		exit;
	}
}
?>
