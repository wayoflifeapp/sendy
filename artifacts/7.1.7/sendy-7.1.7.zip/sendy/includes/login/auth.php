<?php 
	if(isset($_COOKIE['logged_in'])) $cookie = $_COOKIE['logged_in'];
	else $cookie = '';
	
	if(
		!is_null(get_app_info('userID')) && 
		!is_null(get_app_info('email')) && 
		!is_null(get_app_info('password')) &&
		//The cookie's token must still be in login_tokens (not revoked, expired or idle) and belong to this session's user
		sendy_login_token_user($cookie)===(int)get_app_info('userID')
	   )
	   {
	   		start_app();
	   		sendy_csrf_check();
	   }
	else
	{
		$request_uri = $_SERVER['REQUEST_URI'];
		$app_url_path = parse_url(get_app_info('path'), PHP_URL_PATH);
		if($app_url_path!='' && strpos($request_uri, $app_url_path)===0)
			$redirect_to = substr($request_uri, strlen($app_url_path));
		else
			$redirect_to = $request_uri;
		$redirect_to = ltrim($redirect_to, '/');

		if($redirect_to=='')
			echo '<script type="text/javascript">window.location = "'.addslashes(get_app_info('path')).'/login";</script>';
		else
			echo '<script type="text/javascript">window.location = "'.addslashes(get_app_info('path')).'/login?redirect='.addslashes($redirect_to).'";</script>';
		exit;
	}
?>