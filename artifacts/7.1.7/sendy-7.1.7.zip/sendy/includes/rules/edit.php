<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	$id = isset($_POST['id']) && is_numeric($_POST['id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['id']) : "NULL";
	$action = mysqli_real_escape_string($mysqli, $_POST['action']);
	sendy_require_access(sendy_can_access_rule($id) && ($action!='unsub_from_list' || !isset($_POST['val']) || !is_numeric($_POST['val']) || sendy_can_access_list($_POST['val'])));
	if($action=='unsub_from_list')
		$val = isset($_POST['val']) && is_numeric($_POST['val']) ? mysqli_real_escape_string($mysqli, (int)$_POST['val']) : "NULL";
	else
	{
		$val = $action=='notify' ? implode(', ', array_filter(array_map('trim', explode(',', $_POST['val'])))) : $_POST['val'];
		$val = '"'.mysqli_real_escape_string($mysqli, $val).'"';
	}
		
	$actions = array('webhook'=>'endpoint', 'notify'=>'notification_email', 'unsub_from_list'=>'unsubscribe_list_id');
	$column = $actions[$action];

	$q = 'UPDATE rules SET '.$column.'='.$val.' WHERE id = '.$id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
		echo true;
	}
	else
	{
		error_log("[Unable to edit rule]".mysqli_error($mysqli).': in '.__FILE__.' on line '.__LINE__);
		echo false;
	}
?>
