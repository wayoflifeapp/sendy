<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      VARIABLES                       //
	//------------------------------------------------------//
	
	$app = isset($_POST['id']) ? (int)$_POST['id'] : 0;
	$list_id = isset($_POST['list']) ? (int)$_POST['list'] : exit;
	sendy_require_access(sendy_can_access_list($list_id));

	//the custom field
	$the_field = isset($_POST['c_field']) ? trim((string)$_POST['c_field']) : '';
	$type = isset($_POST['c_type']) ? $_POST['c_type'] : '';

	//':' and '%s%' separate custom fields in the database, and a double quote breaks the forms and pages that show field names
	if($the_field=='' || strpos($the_field, ':')!==false || strpos($the_field, '%s%')!==false || strpos($the_field, '"')!==false || ($type!='Text' && $type!='Date'))
	{
		header("Location: ".get_app_info('path')."/custom-fields?i=$app&l=$list_id");
		exit;
	}

	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	$q = 'SELECT custom_fields FROM lists WHERE id = '.$list_id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$custom_fields = $row['custom_fields'];
	    }  
	    
	    //check if custom field exists
	    $custom_fields_array = explode('%s%', $custom_fields);
	    foreach($custom_fields_array as $cf)
	    {
		    $cf_array = explode(':', $cf);
		    if(strtolower($cf_array[0])==strtolower($the_field) || strtolower($the_field)=='name' || strtolower($the_field)=='email')
		    {
			    header("Location: ".get_app_info('path')."/custom-fields?i=$app&l=$list_id&e=1");
			    exit;
		    }
	    }
	    
	    //if nothing is in the custom_fields, just add it to column
	    if($custom_fields == '')
	    	$c_field = $the_field.':'.$type;
	    else
	    {
		    $c_field = $custom_fields.'%s%'.$the_field.':'.$type;
	    }
	    //update custom_fields column
	    $q2 = 'UPDATE lists SET custom_fields = "'.mysqli_real_escape_string($mysqli, $c_field).'" WHERE id = '.$list_id;
	    $r2 = mysqli_query($mysqli, $q2);
	    if ($r2){}
	    
	    //if nothing is in the custom_fields, just add it to column
	    if($custom_fields == '')
	    	$c_field2 = '';
	    else
	    {	    	
	    	$q3 = 'SELECT id, custom_fields FROM subscribers WHERE list = '.$list_id;
	    	$r3 = mysqli_query($mysqli, $q3);
	    	if ($r3)
	    	{
	    	    while($row = mysqli_fetch_array($r3))
	    	    {
	    	    	//retrieved from database
	    			$s_id = $row['id'];
	    			$custom_fields = $row['custom_fields'];
	    			$c_field2 = $custom_fields.'%s%';
	    			
	    			//update custom_fields column
				    $q4 = 'UPDATE subscribers SET custom_fields = "'.mysqli_real_escape_string($mysqli, $c_field2).'" WHERE list = '.$list_id.' AND id = '.$s_id;
				    $r4 = mysqli_query($mysqli, $q4);
	    	    }  
	    	}
	    }
	}
	
	header("Location: ".get_app_info('path')."/custom-fields?i=$app&l=$list_id");
?>