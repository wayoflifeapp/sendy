<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php include('../reports/main.php');?>
<?php 
	//POST variables
	$id = isset($_POST['id']) && is_numeric($_POST['id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['id']) : exit;
	$app = isset($_POST['app']) && is_numeric($_POST['app']) ? mysqli_real_escape_string($mysqli, (int)$_POST['app']) : exit;
	sendy_require_access(sendy_can_access_app($app) && sendy_can_access_subscriber($id));

	//get subscriber data
	$q = 'SELECT * FROM subscribers WHERE id = '.$id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$name_value = $row['name'];
			$name = htmlspecialchars((string)$name_value, ENT_QUOTES, 'UTF-8');
			$email = $row['email'];
			$list_id = $row['list'];
			$unsubscribed = $row['unsubscribed'];
			$bounced = $row['bounced'];
			$complaint = $row['complaint'];
			$confirmed = $row['confirmed'];
			$last_campaign = $row['last_campaign'];
			$join_date = $row['join_date'];
			$last_activity = $row['timestamp'];
			//'No data' is an internal marker that's compared below and never displayed, don't wrap it in _()
			$ip = $row['ip']=='' ? 'No data' : $row['ip'];
			$signedup_country = $row['country']=='' ? 'No data' : $row['country'];
			$referrer = $row['referrer'];
			$gdpr = $row['gdpr'];
			$gdpr_status = $gdpr ? 'Yes' : 'No';
			$notes = $row['notes'];
			$notes_br = nl2br(htmlspecialchars((string)$notes, ENT_QUOTES, 'UTF-8'));
			
			//Opt-in method
			$optin_method = $row['method'];
			if($optin_method==1) $optin_method = _('Single opt-in');
			else if($optin_method==2) $optin_method = _('Double opt-in');
			
			//Added via
			$added_via = $row['added_via'];
			if($added_via=='')
			{
				if($join_date=='') $added_via = _('App interface');
				else $added_via = _('API');
			}
			else
			{
				if($added_via==1 || $join_date=='')
					$added_via = _('Application interface');
				else if($added_via==2 || ($join_date!='' && $ip=='No data' && $signedup_country=='No data'))
					$added_via = _('API');
				else if($added_via==3)
					$added_via = _('Standard subscribe form');
				else if($added_via==4)
					$added_via = _('Resubscribe link');
			}
			
			if($unsubscribed==0)
  				$status = '<span class="label label-success">'._('Subscribed').'</span>';
  			else if($unsubscribed==1)
  				$status = '<span class="label label-important">'._('Unsubscribed').'</span>';
  			if($bounced==1)
	  			$status = '<span class="label label-inverse">'._('Bounced').'</span>';
	  		if($complaint==1)
	  			$status = '<span class="label label-inverse">'._('Marked as spam').'</span>';
  			if($confirmed!=1)
	  			$status = '<span class="label">'._('Unconfirmed').'</span>';
	  			
	  		//check if name is set
	  		if($name=='')
	  			$name = '<em>'._('not set').'</em>';
	    }  
	}
	
	//get list name
	$q = 'SELECT name FROM lists WHERE id = '.$list_id;
	$r = mysqli_query($mysqli, $q);
	if ($r) while($row = mysqli_fetch_array($r)) $list = $row['name'];
?>
<div class="row-fluid">
	<div class="span1">
		<img src="<?php echo get_gravatar($email);?>" class="gravatar" style="margin-bottom: 5px;"/>
		<?php if($gdpr):?>
		<br/>
		<span class="label label-warning" style="margin: 5px 0 0 0px;">GDPR</span>
		<?php endif;?>
	</div>
    <div class="span5">	 		   	
    	<strong><?php echo _('Name');?>: </strong>
	<span id="edit-name" data-value="<?php echo htmlspecialchars($name_value, ENT_QUOTES, 'UTF-8');?>"><?php echo $name;?></span>
	<input type="text" name="name" id="name" value="<?php echo htmlspecialchars($name_value, ENT_QUOTES, 'UTF-8');?>" style="width: 70%; margin-top: 5px; display:none;"/><br/>
    	<script type="text/javascript">
    		$(document).ready(function() {
    			$("#edit-name").mouseover(function(){
	    			$(this).css("text-decoration", "underline");
    			});
    			$("#edit-name").mouseout(function(){
	    			$(this).css("text-decoration", "none");
    			});
    			$("#edit-name").click(function(){
		    		$(this).hide();
		    		$("#name").show();
		    		$("#name").focus();
	    		});
	    		$("#name").blur(function(){
		    		$(this).hide();
		    		$("#edit-name").show();
	    		});
				$("#name").keypress(function(e){if(e.which == 13){e.preventDefault();$(this).blur();}});
				$("#name").focusout(function(){update_name();});
				function update_name()
				{
					$("#edit-name").show(0, function(){
						var new_name = $("#name").val();
						if(new_name != $(this).attr("data-value"))
						$.post("<?php echo get_app_info('path')?>/includes/subscribers/edit.php", { sid: <?php echo $id;?>, name: $("#name").val() },
						  function(data) {
						      if(data != 1)
						      {
						      	$("#edit-name").text($("#edit-name").text());
						      	alert("<?php echo _('Sorry, unable to save. Please try again later!');?>");
						      }
						      else
						      {
							      $("#edit-name").attr("data-value", new_name);
							      if(new_name=="")
								$("#edit-name").html("<em><?php echo addslashes(_('not set'));?></em>");
							      else
								$("#edit-name").text(new_name);
						      }
						  }
						);
					});
		    		$("#name").hide();
				}
    		});
    	</script>
    	
		<strong><?php echo _('Email');?>: </strong>
		<span id="edit-email"><?php echo htmlspecialchars((string)$email, ENT_QUOTES, 'UTF-8');?></span>
		<input type="text" name="email" id="email" value="<?php echo htmlspecialchars((string)$email, ENT_QUOTES, 'UTF-8');?>" style="width: 70%; margin-top: 5px; display:none;"/><br/>
		<script type="text/javascript">
    		$(document).ready(function() {
    			$("#edit-email").click(function(){
		    		$(this).hide();
		    		$("#email").show();
		    		$("#email").focus();
	    		});
	    		$("#edit-email").mouseover(function(){
	    			$(this).css("text-decoration", "underline");
    			});
    			$("#edit-email").mouseout(function(){
	    			$(this).css("text-decoration", "none");
    			});
	    		$("#email").blur(function(){
		    		$(this).hide();
		    		$("#edit-email").show();
	    		});
	    		$("#email").keypress(function(e){if(e.which == 13)
				{
					update_email();
					$(this).unbind("focusout");
				}});
	    		$("#email").focusout(function(){
					update_email();
					$(this).unbind("focusout");
				});
				function update_email()
				{			
					$("#edit-email").show(0, function(){
						if($("#email").val() != $(this).text())
						$.post("<?php echo get_app_info('path')?>/includes/subscribers/edit.php", { sid: <?php echo $id;?>, email: $("#email").val(), app: <?php echo $app;?> },
						  function(data) {
							  $("#email").focusout(function(){update_email();});
						      if(data != 1)
						      {
						      	 $("#edit-email").text($("#edit-email").text());
						      	 alert(data);
						      }
						      else
						      {
								  $("#edit-email").text($("#email").val());
						      }
						  }
						);
						$("#email").hide();
					});
				}
    		});
    	</script>
    	
    	<?php if($join_date!=''):?>
    	<strong><?php echo _('Joined');?>: </strong>
    	<span><?php echo parse_date($join_date, 'modal', false)?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($last_activity!=''):?>
    	<strong><?php echo _('Last activity');?>: </strong>
    	<span><?php echo parse_date($last_activity, 'modal', false)?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($optin_method!=''):?>
    	<strong><?php echo _('Opt-in method');?>: </strong>
    	<span><?php echo $optin_method;?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($confirmed):?>
    	<strong><?php echo _('Added via');?>: </strong>
    	<span><?php echo $added_via;?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($ip!='' && $ip!='No data'):?>
    	<strong><?php echo _('IP address');?>: </strong>
    	<span><?php echo htmlspecialchars((string)$ip, ENT_QUOTES, 'UTF-8');?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($signedup_country!='' && $signedup_country!='No data'):?>
    	<strong><?php echo _('Country');?>: </strong>
    	<span><?php echo country_code_to_country($signedup_country).' ('.htmlspecialchars((string)$signedup_country, ENT_QUOTES, 'UTF-8').')';?></span>
    	<br/>
    	<?php endif;?>
    	
    	<?php if($referrer!=''):?>
    	<strong><?php echo _('Signed up from');?>: </strong>
    	<?php
    		$referrer_esc = htmlspecialchars((string)$referrer, ENT_QUOTES, 'UTF-8');
    		$referrer_label = htmlspecialchars(strlen($referrer)>30 ? substr($referrer, 0, 30).'..' : (string)$referrer, ENT_QUOTES, 'UTF-8');
    		//Only link http(s) referrers so a stored javascript: URL can't run when clicked
    		$referrer_is_url = preg_match('/^https?:\/\//i', $referrer);
    	?>
    	<span><?php if($referrer_is_url):?><a href="<?php echo $referrer_esc;?>" title="<?php echo $referrer_esc;?>" target="_blank" rel="noopener noreferrer"><?php echo $referrer_label;?></a><?php else: echo $referrer_label; endif;?></span>
    	<br/>
    	<?php endif;?>
		
		<?php 
			//get custom fields and values
			$q = 'SELECT lists.custom_fields, subscribers.custom_fields AS custom_values FROM lists, subscribers WHERE subscribers.id = '.$id.' AND lists.id = subscribers.list';
			$r = mysqli_query($mysqli, $q);
			if ($r)
			{
			    while($row = mysqli_fetch_array($r))
			    {
					$custom_fields = $row['custom_fields'];
					$custom_values = $row['custom_values'];
			    }
			    
			    //if there's custom fields for this list, show custom fields and their values
			    if($custom_fields!='')
			    {
				    echo '<hr/><h4 style="margin: -15px 0 -15px 0;">Custom fields</h4><hr style="margin-bottom: 5px;"/>';
				    $custom_fields_array = explode('%s%', $custom_fields);
				    
				    $i = 0;
				    foreach($custom_fields_array as $cf)
				    {
					    $cf_array = explode(':', $cf);
					    $cf_field = $cf_array[0];
					    $cf_format = $cf_array[1];
					    $cf_value_array = explode('%s%', $custom_values);
					    $cf_field_without_dash = str_replace('-', '_dash_', $cf_field);
					    $cf_field_without_dash = str_replace('?', '_question_', $cf_field_without_dash);
					    
					    //format date if format is date
					    if($cf_format=='Date' && $cf_value_array[$i]!='')
					    {
						    $cf_value_array[$i] = date("M d, Y", $cf_value_array[$i]);
					    }
					    
					    //check if value is empty
					    if($cf_value_array[$i]=='')
					    	$cf_value_array[$i] = '<em>not set</em>';
					    else
					    	$cf_value_array[$i] = htmlspecialchars((string)$cf_value_array[$i], ENT_QUOTES, 'UTF-8');
					    
					    echo '<strong>'.$cf_field.': </strong>';
					    
					    $cf_field_without_dash = str_replace(" ", "", $cf_field_without_dash);
					    
					    //Check if custom field name begins with a number, if so, append 'ncf_' to custom field name
					    $cf_field_without_dash_first_number = is_numeric(substr($cf_field_without_dash, 0, 1)) ? true : false;
					    if($cf_field_without_dash_first_number) $cf_field_without_dash = 'ncf_'.$cf_field_without_dash;
					    
					    echo'
					    <span id="edit-'.$cf_field_without_dash.'">'.$cf_value_array[$i].'</span>
					    <input type="text" name="'.$cf_field_without_dash.'" id="'.$cf_field_without_dash.'" value="'.strip_tags($cf_value_array[$i]).'" style="width: 70%; margin-top: 5px; display:none;"/>
					    <br/>';
					    ?>
					    
					    <script type="text/javascript">
				    		$(document).ready(function() {
				    			$("#edit-<?php echo $cf_field_without_dash;?>").click(function(){
						    		$(this).hide();
						    		$("#<?php echo $cf_field_without_dash;?>").show();
						    		$("#<?php echo $cf_field_without_dash;?>").focus();
					    		});
					    		$("#edit-<?php echo $cf_field_without_dash;?>").mouseover(function(){
					    			$(this).css("text-decoration", "underline");
				    			});
				    			$("#edit-<?php echo $cf_field_without_dash;?>").mouseout(function(){
					    			$(this).css("text-decoration", "none");
				    			});
					    		$("#<?php echo $cf_field_without_dash;?>").blur(function(){
						    		$(this).hide();
						    		$("#edit-<?php echo $cf_field_without_dash;?>").show();
					    		});
					    		$("#<?php echo $cf_field_without_dash;?>").keypress(function(e){
								    if(e.which == 13)
								    {
								    	update_<?php echo $cf_field_without_dash;?>();
								    }
								});
								$("#<?php echo $cf_field_without_dash;?>").focusout(function(){update_<?php echo $cf_field_without_dash;?>();});
								function update_<?php echo $cf_field_without_dash;?>()
								{			
									$("#edit-<?php echo $cf_field_without_dash;?>").show(0, function(){
										if($("#<?php echo $cf_field_without_dash;?>").val() != $(this).text())
										$.post("<?php echo get_app_info('path')?>/includes/subscribers/edit.php", { sid: <?php echo $id;?>, <?php echo $cf_field_without_dash;?>: $("#<?php echo $cf_field_without_dash;?>").val() },
										  function(data) {
										      if(data != 1)
										      {
										      	 $("#edit-<?php echo $cf_field_without_dash;?>").text($("#edit-<?php echo $cf_field_without_dash;?>").text());
										      	 alert(data);
										      }
										      else
										      {
												  $("#edit-<?php echo $cf_field_without_dash;?>").text($("#<?php echo $cf_field_without_dash;?>").val());
										      }
										  }
										);
										$("#<?php echo $cf_field_without_dash;?>").hide();
									});
								}
				    		});
				    	</script>
					    
					    <?php
					    
					    $i++;
				    }
				}
			}
		?>
    </div>
    <div class="span6">
		<div style="margin-bottom: 10px;"><strong><?php echo _('List');?></strong>: <span class="label label-info"><?php echo $list;?></span></div>
		<div style="margin-bottom: 10px;"><strong><?php echo _('Status');?></strong>: <?php echo $status;?></div>
		<strong><?php echo _('Notes');?>:</strong>
		<br/>
		<div id="subscriber-notes" class="alert alert-info">
			<div id="edit-note"><?php echo $notes=='' ? _('Click to add a note for this subscriber.') : $notes_br;?></div>
			<textarea id="note" style="display:none; width: 100%; height: 190px;"><?php echo htmlspecialchars((string)$notes, ENT_QUOTES, 'UTF-8');?></textarea>
		</div>
		<script type="text/javascript">
			$("#edit-note").mouseover(function(){
    			$(this).css("text-decoration", "underline");
			});
			$("#edit-note").mouseout(function(){
    			$(this).css("text-decoration", "none");
			});
			$("#edit-note").click(function(){
	    		$(this).hide();
	    		$("#note").show();
	    		$("#note").focus();
    		});
    		$("#note").blur(function(){
	    		$(this).hide();
	    		$("#edit-note").show();
	    		$("#edit-note").html("<?php echo _('Saving..')?>");
    		});
			$("#note").focusout(function(){update_note();});
			$("#note").keypress(function(e){if((e.metaKey || e.ctrlKey) && e.which == 13){$(this).blur();}});
			function update_note()
			{
				$("#edit-note").show(1, function(){
					if($("#note").val() != $(this).text())
					$.post("<?php echo get_app_info('path')?>/includes/subscribers/edit.php", { sid: <?php echo $id;?>, note: $("#note").val() },
					  function(data) {
					      if(data != 1)
					      {
					      	$("#edit-note").text($("#edit-note").text());
					      	alert("<?php echo _('Sorry, unable to save. Please try again later!');?>");
					      }
					      else
					      {
						      if($("#note").val()=="")
						      	  $("#edit-note").html("<?php echo _('Click to add a note for this subscriber.');?>");
						      else
							      $("#edit-note").html(nl2br($("<div>").text($("#note").val()).html()));
					      }
					  }
					);
				});
	    		$("#note").hide();
			}
			function nl2br (str, is_xhtml) {   
			    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';    
			    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1'+ breakTag +'$2');
			}
		</script>
    </div>
</div>
<hr>
<h4><?php echo _('Campaign activity');?></h4><br/>
<div class="subscriber-campaign-activity-scroll">
<table class="table table-striped table-condensed responsive subscriber-campaign-activity">
  <thead>
    <tr>
      <th><?php echo _('Campaign');?></th>
      <th><?php echo _('Opens');?></th>
      <th><?php echo _('Clicks');?></th>
      <th><?php echo _('Country');?></th>
    </tr>
  </thead>
  <tbody>
  	<?php
	  	//Check if `seg` table have any rows
	  	$seg_count = 0;
	  	$q = 'SELECT COUNT(*) FROM seg';
	  	$r = mysqli_query($mysqli, $q);
	  	if ($r) while($row = mysqli_fetch_array($r)) $seg_count = $row['COUNT(*)'];

	  	//scope campaigns to this subscriber's list (directly targeted, or via a segment of this list), not the whole app
	  	if($seg_count==0)
	  		$q = 'SELECT campaigns.* FROM campaigns WHERE campaigns.userID = '.get_app_info('main_userID').' AND campaigns.app = '.$app.' AND campaigns.opens_tracking!=2 AND FIND_IN_SET("'.$list_id.'", campaigns.to_send_lists) > 0 ORDER BY campaigns.sent DESC LIMIT 20';
	  	else
	  	{
	  		//Remove ONLY_FULL_GROUP_BY from sql_mode since we SELECT campaigns.* with a GROUP BY below
	  		$q = 'SET SESSION sql_mode = ""';
	  		$r = mysqli_query($mysqli, $q);
	  		if (!$r) error_log("[Unable to set sql_mode]".mysqli_error($mysqli).': in '.__FILE__.' on line '.__LINE__);

	  		$q = 'SELECT campaigns.* FROM seg
	  			LEFT JOIN campaigns ON
	  			(
	  				(FIND_IN_SET(seg.id, campaigns.segs) AND seg.list = '.$list_id.')
	  				OR
	  				FIND_IN_SET("'.$list_id.'", campaigns.to_send_lists) > 0
	  			)
	  			WHERE campaigns.userID = '.get_app_info('main_userID').' AND campaigns.app = '.$app.' AND campaigns.opens_tracking!=2
	  			GROUP BY campaigns.id
	  			ORDER BY campaigns.sent DESC
	  			LIMIT 20';
	  	}
	  	$r = mysqli_query($mysqli, $q);
	  	if ($r && mysqli_num_rows($r) > 0)
	  	{
	  		$has_activity = false;
	  	    while($row = mysqli_fetch_array($r))
	  	    {
	  	    	//opens and country data
	  	    	$country = '';
	  	    	$s_id = '';
	  	    	$open_count = 0;
	  	    	$campaign_id = $row['id'];
	  			$title = $row['title'];
	  			$opens = $row['opens'];
	  			$opens_tracking = $row['opens_tracking'];
	  			$links_tracking = $row['links_tracking'];
				$opens_array = explode(',', $opens);
				$links_clicked = '';
				$click_count = 0;
				$link_array = array();
				$link_clicks = array();
				for($z=0;$z<count($opens_array);$z++)
				{
					// Legacy imported records can omit the country portion. Split only once
					// and treat a missing country as unavailable instead of indexing an absent value.
					$subscriber_id = explode(':', $opens_array[$z], 2);
					if(isset($subscriber_id[0]) && trim($subscriber_id[0])==$id)
					{
						$s_id = $subscriber_id[0];
						if(isset($subscriber_id[1]) && trim($subscriber_id[1])!='')
							$country = trim($subscriber_id[1]);
						$has_activity = true;
						$open_count += 1;
					}
		  		}
		  		
		  		//get links data
				$q2 = 'SELECT link, clicks FROM links WHERE campaign_id = '.$campaign_id;
				$r2 = mysqli_query($mysqli, $q2);
				if ($r2 && mysqli_num_rows($r2) > 0)
				{
					while($row = mysqli_fetch_array($r2))
		  		    {
		  				$clicks = $row['clicks'];
		  				$link = $row['link'];
		  				$clicks_array = explode(',', $clicks);
		  				foreach($clicks_array as $ca)
		  				if($ca==$id)
		  				{
		  					$click_count++;
		  					if(!in_array($link, $link_array))
			  					array_push($link_array, $link);
			  				$link_clicks[$link] = isset($link_clicks[$link]) ? $link_clicks[$link] + 1 : 1;
		  				}
		  		    }
		  		    //show each link in full (wrapped, not truncated) with how many times this subscriber clicked it
		  		    for($y=0;$y<count($link_array);$y++)
		  		    {
		  		    	$link = $link_array[$y];
		  		    	$link_esc = htmlspecialchars($link, ENT_QUOTES, 'UTF-8');
		  		    	//emphasize the host so links are scannable, de-emphasize the path/query
		  		    	if(preg_match('/^([a-z][a-z0-9+.-]*:\/\/[^\/?#]+)(.*)$/is', $link, $m))
		  		    		$link_html = '<span class="click-link-host">'.htmlspecialchars($m[1], ENT_QUOTES, 'UTF-8').'</span><span class="click-link-path">'.htmlspecialchars($m[2], ENT_QUOTES, 'UTF-8').'</span>';
		  		    	else
		  		    		$link_html = '<span class="click-link-path">'.$link_esc.'</span>';
		  		    	$link_html = preg_match('/^https?:\/\//i', $link) ? '<a href="'.$link_esc.'" target="_blank" rel="noopener noreferrer" class="click-link-url">'.$link_html.'</a>' : '<span class="click-link-url">'.$link_html.'</span>';
		  		    	$times = $link_clicks[$link];
		  		    	$links_clicked .= '<li>'.$link_html.'<span class="click-link-count" title="'.htmlspecialchars(_('Clicks'), ENT_QUOTES, 'UTF-8').'">'.$times.'&times;</span></li>';
		  		    }
		  		    $links_clicked = '<ul class="click-links-list">'.$links_clicked.'</ul>';
		  		}
		  		
		  		if($s_id!='')
		  		{
		  			$cty = country_code_to_country($country);
		  			if($cty=='')
		  				$cty = _('Not detected');
		  				
		  			echo '<tr>';
		  			
		  			if(!get_app_info('is_sub_user') || (get_app_info('is_sub_user') && get_app_info('reports_only')==0))
				  		echo '<td><a href="'.get_app_info('path').'/report?i='.$app.'&c='.$campaign_id.'" title="'._('View report for').' '.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'">'.$title.'</a></td>';
				  	else
				  		echo '<td>'.$title.'</td>';
				    
				    echo '<td>'.$open_count.'</td>';
				    
					if($links_tracking==0)
						echo '<td>'._('Tracking disabled').'</td>';
					else if($links_tracking==2)
						echo '<td>'._('Tracked anonymously').'</td>';
					else if(count($link_array)==0)
						echo '<td>0</td>';
					else
						echo '<td><a href="javascript:void(0)" class="click-links-trigger" title="'.htmlspecialchars(_('Links clicked'), ENT_QUOTES, 'UTF-8').'" data-content="'.htmlspecialchars($links_clicked, ENT_QUOTES, 'UTF-8').'" id="click-links-'.$campaign_id.'" aria-haspopup="true">'.$click_count.'</a></td>';

				    echo '
				      <td>'.$cty.'</td>
				    </tr>
				  	';
		  		}
	  	    }  
	  	    if(!$has_activity)
	  	    {
		  	    echo '
			  	<tr>
			      <td>'._('No activity.').'</td>
			      <td></td>
			      <td></td>
			      <td></td>
			    </tr>
			  	';
	  	    }
	  	}
	  	else
	  	{
		  	echo '
		  	<tr>
		      <td>'._('No activity.').'</td>
		      <td></td>
		      <td></td>
		      <td></td>
		    </tr>
		  	';
	  	}
  	?>
  </tbody>
</table>
</div>
<style type="text/css">
	/* Clicks count: larger, padded hit area without shifting the table layout */
	.click-links-trigger {
		display: inline-block;
		text-align: center;
		padding: 6px 12px;
		margin: -6px -12px;
		border-radius: 6px;
		text-decoration: underline;
		text-underline-offset: 3px;
		cursor: pointer;
	}
	.click-links-trigger:hover,
	.click-links-trigger:focus,
	.click-links-trigger[aria-expanded="true"] {
		background: rgba(128, 128, 128, 0.12);
		outline: none;
	}

	/* Links clicked popover */
	.popover.click-links-popover {
		z-index: 2060;
		width: max-content;
		max-width: 460px;
		max-width: min(460px, calc(100vw - 32px));
	}
	.popover.click-links-popover:not(.in) {
		pointer-events: none;
	}
	/* invisible bridge over the gap between the number and the popover so it doesn't close mid-move */
	.popover.click-links-popover:before {
		content: "";
		position: absolute;
	}
	.popover.click-links-popover.left:before {
		top: -8px;
		bottom: -8px;
		right: -16px;
		width: 16px;
	}
	.popover.click-links-popover.bottom:before {
		left: -8px;
		right: -8px;
		top: -16px;
		height: 16px;
	}
	.click-links-popover .popover-content {
		padding: 0;
	}
	.click-links-list {
		list-style: none;
		margin: 0;
		padding: 4px 0;
		max-height: 280px;
		overflow-y: auto;
		overscroll-behavior: contain;
	}
	.click-links-list li {
		display: flex;
		align-items: flex-start;
		gap: 12px;
		padding: 9px 14px;
		font-size: 13px;
		line-height: 1.45;
	}
	.click-links-list li + li {
		border-top: 1px solid rgba(128, 128, 128, 0.18);
	}
	.click-link-url {
		flex: 1;
		min-width: 0;
		color: inherit;
		overflow-wrap: anywhere;
		word-break: break-word;
		text-decoration: none;
	}
	a.click-link-url:hover,
	a.click-link-url:focus {
		color: inherit;
		text-decoration: underline;
		text-underline-offset: 3px;
	}
	.click-link-host {
		font-weight: 600;
	}
	.click-link-path {
		opacity: 0.65;
	}
	.click-link-count {
		flex: none;
		margin-top: 1px;
		padding: 0 7px;
		border-radius: 999px;
		background: rgba(128, 128, 128, 0.15);
		font-size: 12px;
		line-height: 18px;
		font-variant-numeric: tabular-nums;
	}
</style>
<script type="text/javascript">
	$(document).ready(function() {
		var $triggers = $(".click-links-trigger");
		var $active = null, hideTimer = null;

		//clear out any popover left behind from a previously loaded subscriber
		$("body > .click-links-popover").remove();
		$(document).off(".clickLinks");
		$("#subscriber-info, #subscriber-info .modal-body, .subscriber-campaign-activity-scroll").off(".clickLinks");
		if(!$triggers.length) return;

		function hideNow() {
			clearTimeout(hideTimer);
			if($active) {
				$active.attr("aria-expanded", "false").popover("hide");
				$active = null;
			}
		}
		function scheduleHide() {
			clearTimeout(hideTimer);
			hideTimer = setTimeout(hideNow, 300);
		}
		function show($t) {
			clearTimeout(hideTimer);
			if($active && $active[0] === $t[0]) return;
			hideNow();
			$t.popover("show").attr("aria-expanded", "true");
			$active = $t;
		}

		$triggers.popover({
			trigger: "manual",
			container: "body",
			html: true,
			placement: function(tip, el) {
				//open to the left when there's room, otherwise drop below the number
				return $(el).offset().left - $(window).scrollLeft() > 480 ? "left" : "bottom";
			},
			template: '<div class="popover click-links-popover" role="dialog"><div class="arrow"></div><div class="popover-inner"><h3 class="popover-title"></h3><div class="popover-content"><div></div></div></div></div>'
		}).each(function() {
			var $t = $(this);
			$t.data("popover").tip()
				.on("mouseenter focusin", function() { clearTimeout(hideTimer); })
				.on("mouseleave focusout", scheduleHide);
		})
		//keep popover show/hide events from bubbling up to the modal
		.on("show shown hide hidden", function(e) { e.stopPropagation(); })
		.on("mouseenter focus", function() { show($(this)); })
		.on("mouseleave blur", scheduleHide)
		.on("click", function(e) { e.preventDefault(); show($(this)); });

		//tap/click outside, Esc, scrolling or closing the modal dismisses it
		$(document)
			.on("click.clickLinks touchstart.clickLinks", function(e) {
				if($active && !$(e.target).closest(".click-links-trigger, .click-links-popover").length) hideNow();
			})
			.on("keyup.clickLinks", function(e) { if(e.which == 27) hideNow(); });
		$("#subscriber-info .modal-body, .subscriber-campaign-activity-scroll").on("scroll.clickLinks", hideNow);
		$("#subscriber-info").on("hide.clickLinks", function(e) { if(e.target === this) hideNow(); });
	});
</script>
