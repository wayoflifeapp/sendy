/*
 * Adds Sendy's CSRF token (from <meta name="csrf-token">) to every same-origin POST:
 * jQuery ajax, fetch(), XMLHttpRequest and POST forms. Checked by sendy_csrf_check() in includes/functions.php.
 */
(function (window, document) {
	"use strict";

	var meta = document.querySelector('meta[name="csrf-token"]');
	var token = meta ? meta.getAttribute("content") : "";
	if (!token) return;

	window.SENDY_CSRF_TOKEN = token;

	function isSameOrigin(url) {
		try {
			return new URL(url || "", window.location.href).origin === window.location.origin;
		} catch (e) {
			return false;
		}
	}

	function needsToken(method, url) {
		method = (method || "GET").toUpperCase();
		return method !== "GET" && method !== "HEAD" && method !== "OPTIONS" && isSameOrigin(url);
	}

	//XMLHttpRequest: covers jQuery $.post/$.ajax (which use XHR) and CKEditor's drag & drop uploads.
	//The header is set once only, a repeated XHR header is joined into "a, b" and would fail the check
	var xhrOpen = XMLHttpRequest.prototype.open;
	var xhrSend = XMLHttpRequest.prototype.send;
	var xhrSetHeader = XMLHttpRequest.prototype.setRequestHeader;
	XMLHttpRequest.prototype.open = function (method, url) {
		this._sendyCsrf = needsToken(method, url);
		this._sendyCsrfSet = false;
		return xhrOpen.apply(this, arguments);
	};
	XMLHttpRequest.prototype.setRequestHeader = function (name) {
		if (String(name).toLowerCase() === "x-csrf-token") this._sendyCsrfSet = true;
		return xhrSetHeader.apply(this, arguments);
	};
	XMLHttpRequest.prototype.send = function () {
		if (this._sendyCsrf && !this._sendyCsrfSet) {
			try { xhrSetHeader.call(this, "X-CSRF-Token", token); } catch (e) {}
		}
		return xhrSend.apply(this, arguments);
	};

	//fetch() (passkeys)
	if (window.fetch) {
		var origFetch = window.fetch;
		window.fetch = function (input, init) {
			var url = typeof input === "string" ? input : (input && input.url);
			var method = (init && init.method) || (input && typeof input !== "string" && input.method) || "GET";
			if (needsToken(method, url)) {
				init = init || {};
				var headers = new Headers(init.headers || (input && typeof input !== "string" ? input.headers : undefined));
				headers.set("X-CSRF-Token", token);
				init.headers = headers;
			}
			return origFetch.call(this, input, init);
		};
	}

	//POST forms, including ones added later or submitted with form.submit()
	function addToForm(form) {
		if (!form || !form.getAttribute) return;
		if ((form.getAttribute("method") || "GET").toUpperCase() !== "POST") return;
		if (!isSameOrigin(form.getAttribute("action") || window.location.href)) return;
		var input = form.querySelector('input[name="csrf_token"]');
		if (!input) {
			input = document.createElement("input");
			input.type = "hidden";
			input.name = "csrf_token";
			form.appendChild(input);
		}
		input.value = token;
	}

	document.addEventListener("submit", function (e) { addToForm(e.target); }, true);

	var formSubmit = HTMLFormElement.prototype.submit;
	HTMLFormElement.prototype.submit = function () {
		addToForm(this);
		return formSubmit.apply(this, arguments);
	};

	function addToAllForms() {
		var forms = document.getElementsByTagName("form");
		for (var i = 0; i < forms.length; i++) addToForm(forms[i]);
	}
	if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", addToAllForms);
	else addToAllForms();
})(window, document);
