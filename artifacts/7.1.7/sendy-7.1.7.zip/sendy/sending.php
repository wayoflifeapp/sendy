<?php include('includes/functions.php');?>
<?php include('includes/login/auth.php');?>
<?php include('includes/helpers/locale.php');?>
<?php 
	// PayPal returns paid users to this endpoint with a GET request. Keep that
	// compatibility path while requiring a valid Sendy login and ownership below.
	$request = $_SERVER['REQUEST_METHOD'] === 'POST' ? $_POST : $_GET;
	$campaign_id = isset($request['c']) && is_numeric($request['c']) ? (int)$request['c'] : exit;
	$email_list = mysqli_real_escape_string($mysqli, $request['e']);
	$email_list_exclude = mysqli_real_escape_string($mysqli, $request['ex']);
	$email_lists_segs = mysqli_real_escape_string($mysqli, $request['e_segs']);
	$email_lists_segs_excl = mysqli_real_escape_string($mysqli, $request['ex_segs']);
	//List and segment params are comma-separated IDs and get echoed into inline JS below, reject anything else
	foreach(array($email_list, $email_list_exclude, $email_lists_segs, $email_lists_segs_excl) as $id_list)
		if(!preg_match('/^[0-9,]*$/', (string)$id_list)) { http_response_code(400); exit; }
	$app = isset($request['i']) && is_numeric($request['i']) ? (int)$request['i'] : exit;
	$schedule = isset($request['s']) ? $request['s'] : 'false';
	$cron = isset($request['cr']) && is_numeric($request['cr']) ? (int)$request['cr'] : 0;
	$total_recipients = isset($request['recipients']) && is_numeric($request['recipients']) ? (int)$request['recipients'] : exit;

	$allowed_app = get_app_info('is_sub_user') ? (int)get_app_info('restricted_to_app') : $app;
	$q = 'SELECT campaigns.id FROM campaigns, apps WHERE campaigns.id = '.$campaign_id.' AND campaigns.app = '.$app.' AND apps.id = campaigns.app AND apps.userID = '.(int)get_app_info('main_userID').' AND apps.id = '.$allowed_app;
	$r = mysqli_query($mysqli, $q);
	if(!$r || mysqli_num_rows($r) !== 1) { http_response_code(403); exit; }
	
	//Set language
	$q = 'SELECT login.language FROM campaigns, login WHERE campaigns.id = '.$campaign_id.' AND login.app = campaigns.app';
	$r = mysqli_query($mysqli, $q);
	if ($r && mysqli_num_rows($r) > 0) while($row = mysqli_fetch_array($r)) $language = $row['language'];
	set_locale($language);
	
	//check if sent
	$q = 'SELECT sent, quota_deducted FROM campaigns WHERE id = '.$campaign_id;
	$r = mysqli_query($mysqli, $q);
	if ($r && mysqli_num_rows($r) > 0)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$sent = stripslashes((string)$row['sent']);
			$current_quota_deducted = $row['quota_deducted']=='' ? 0 : $row['quota_deducted'];
	    }  
	}
	
	//Check if monthly quota needs to be updated
	$q = 'SELECT allocated_quota, current_quota FROM apps WHERE id = '.$app;
	$r = mysqli_query($mysqli, $q);
	if($r) 
	{
		while($row = mysqli_fetch_array($r)) 
		{
			$allocated_quota = $row['allocated_quota'];
			$current_quota = $row['current_quota'];
		}
	}
	//Update quota if a monthly limit was set
	if($allocated_quota!=-1)
	{
		if($schedule!='true') $current_quota_deducted = 0;
		
		$updated_quota = ($current_quota + $total_recipients) - $current_quota_deducted;
		
		//if so, update quota
		$q = 'UPDATE apps SET current_quota = '.$updated_quota.' WHERE id = '.$app;
		mysqli_query($mysqli, $q);
	}

//if scheduled
if($schedule=='true'):

	//get POST variables
	$the_date = mysqli_real_escape_string($mysqli, $request['date']);
	$timezone = mysqli_real_escape_string($mysqli, $request['timezone']);
	
	$q = 'UPDATE campaigns SET send_date = "'.$the_date.'", lists = "'.$email_list.'", lists_excl = "'.$email_list_exclude.'", segs = "'.$email_lists_segs.'", segs_excl = "'.$email_lists_segs_excl.'", timezone = "'.$timezone.'", quota_deducted = '.$total_recipients.' WHERE id = '.$campaign_id;
	$r = mysqli_query($mysqli, $q);
	if($r):
	?>
	<html>
		<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="robots" content="noindex, nofollow">
		<link rel="Shortcut Icon" type="image/ico" href="<?php echo APP_PATH;?>/img/favicon.png">
		<title><?php echo _('Your campaign has been scheduled');?></title>
	</head>
	<style type="text/css">
		body{
			background: #f7f9fc;
			font-family: Helvetica, Arial;
		}
		#wrapper 
		{
			background: #ffffff;
			-webkit-box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			-moz-box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			
			width: 280px;
			height: 250px;
			
			margin: -190px 0 0 -140px;
			position: absolute;
			top: 50%;
			left: 50%;
			-webkit-border-radius: 5px;
			-moz-border-radius: 5px;
			border-radius: 5px;
			padding: 10px 20px;
		}
		p{
			text-align: center;
			font-size: 12px;
			line-height: 16px;
		}
		h2{
			font-weight: normal;
			text-align: center;
		}
		a{
			color: #000;
		}
		a:hover{
			text-decoration: none;
		}
		#sending{
			margin-left: 95px;
		}
		#top-pattern{
			margin-top: -8px;
			height: 8px;
			background: url("<?php echo APP_PATH; ?>/img/top-pattern2.gif") repeat-x 0 0;
			background-size: auto 8px;
		}
	</style>
	<body>
		<div id="top-pattern"></div>
		<div id="wrapper">
			<h2><?php echo _('Your campaign has been scheduled');?>!</h2>
			<img id="sending" src="<?php echo APP_PATH;?>/img/scheduled.jpg?2" height="92" />
			<p><?php echo _('You will be notified by email once your campaign has been sent.');?></p>
		</div>
	</body>
	</html>
	<?php endif;?>

<?php else:?>

	<!DOCTYPE html>
	<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<meta name="robots" content="noindex, nofollow">
			<script type="text/javascript" src="<?php echo APP_PATH;?>/js/jquery-4.0.0.min.js"></script>
			<script type="text/javascript" src="<?php echo APP_PATH;?>/js/jquery-compat.js"></script>
			<?php echo sendy_csrf_tags();?>
			<link rel="Shortcut Icon" type="image/ico" href="<?php echo APP_PATH;?>/img/favicon.png">
			<title><?php echo _('Now sending');?></title>
			<?php if($sent==''):?>
			<script type="text/javascript">
				$(document).ready(function() {
					
					<?php if($email_list!=''):?>
						list = "<?php echo $email_list;?>";
					<?php else:?>
						list = "0";
					<?php endif;?>
					
					<?php if($email_lists_segs!=''):?>
						list_segs = "<?php echo $email_lists_segs;?>";
					<?php else:?>
						list_segs = "0";
					<?php endif;?>
					
					<?php if($email_list_exclude!=''):?>
						list_excl = "<?php echo $email_list_exclude;?>";
					<?php else:?>	
						list_excl = "0";
					<?php endif;?>
					
					<?php if($email_lists_segs_excl!=''):?>
						list_excl_segs = "<?php echo $email_lists_segs_excl;?>";
					<?php else:?>	
						list_excl_segs = "0";
					<?php endif;?>
					
					$.post("<?php echo APP_PATH;?>/includes/create/send-now.php", { campaign_id: <?php echo $campaign_id;?>, email_list: list, email_list_exclude: list_excl, email_lists_segs: list_segs, email_lists_segs_excl: list_excl_segs, app: <?php echo $app;?>, cron: <?php echo $cron;?>, total_recipients: <?php echo $total_recipients;?> },
					  function(data) {
					      if(data){}
					  }
					);
				});
			</script>
			<?php endif;?>
		</head>
		<style type="text/css">
		body{
			background: #f7f9fc;
			font-family: Helvetica, Arial;
		}
		#wrapper 
		{
			background: #ffffff;
			-webkit-box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			-moz-box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			box-shadow: 0px 16px 46px -22px rgba(0,0,0,0.75);
			
			width: 350px;
			height: 250px;
			
			margin: -190px 0 0 -185px;
			position: absolute;
			top: 50%;
			left: 50%;
			-webkit-border-radius: 5px;
			-moz-border-radius: 5px;
			border-radius: 5px;
			padding: 10px 20px;
		}
		p{
			text-align: center;
			font-size: 12px;
			line-height: 16px;
		}
		h2{
			font-weight: normal;
			text-align: center;
		}
		a{
			color: #000;
			text-decoration: none;
		}
		a:hover{
			text-decoration: underline;
		}
		#sending{
			margin-left: 130px;
		}
		#top-pattern{
			margin-top: -8px;
			height: 8px;
			background: url("<?php echo APP_PATH; ?>/img/top-pattern2.gif") repeat-x 0 0;
			background-size: auto 8px;
		}
		</style>
		<body>
			<div id="top-pattern"></div>
			<div id="wrapper">
				<h2><?php echo _('Your campaign is on the way!');?></h2>
				<img id="sending" src="<?php echo APP_PATH;?>/img/email-notifications/email-sending.gif" height="150" />
				<p><?php echo _('You can close this window and your campaign will continue to send. You will be notified by email once your campaign has completed sending.');?></p>
			</div>
		</body>
	</html>
	
<?php endif;?>
