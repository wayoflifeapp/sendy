<?php 
	define('APP_PATH', 'http://');
	$dbHost = 'localhost'; //MySQL Hostname
	$dbUser = 'root'; //MySQL Username
	$dbPass = ''; //MySQL Password
	$dbName = 'sendy'; //MySQL Database Name
	$charset = 'utf8mb4';
	$dbPort = 3306;	
	define('COOKIE_DOMAIN', '');
?>
