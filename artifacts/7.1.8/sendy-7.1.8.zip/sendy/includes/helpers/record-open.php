<?php
	//------------------------------------------------------------------------//
	// Records an email open. Used by t.php (the tracking pixel) and by l.php,
	// r.php and w.php, which used to curl /t/ from the server instead. That
	// curl held a PHP worker for up to 5 seconds and, because the request came
	// from the server, recorded the server's country instead of the subscriber's.
	//------------------------------------------------------------------------//

	require_once __DIR__.'/geo/geolite2/vendor/autoload.php';

	if(!function_exists('sendy_tracking_client_ip'))
	{
		//--------------------------------------------------------------//
		function sendy_tracking_client_ip()
		//--------------------------------------------------------------//
		{
			if (getenv("HTTP_CLIENT_IP")) {
				$ip = getenv("HTTP_CLIENT_IP");
			} elseif (getenv("HTTP_X_FORWARDED_FOR")) {
				$ip = getenv("HTTP_X_FORWARDED_FOR");
			} else {
				$ip = getenv("REMOTE_ADDR");
			}
			$ip_array = explode(',', (string)$ip);
			if(array_key_exists(1, $ip_array)) $ip = trim($ip_array[0]);
			return (string)$ip;
		}

		//--------------------------------------------------------------//
		function sendy_tracking_country($ip)
		//--------------------------------------------------------------//
		{
			$country = '';
			if(version_compare(PHP_VERSION, '5.4')==-1)
			{
				include_once(__DIR__.'/geo/geolite/geoip.inc');
				$gi = geoip_open(__DIR__.'/geo/geolite/GeoIP.dat', GEOIP_STANDARD);
				$country = geoip_country_code_by_addr($gi, $ip);
				geoip_close($gi);
			}
			else
			{
				try
				{
					$reader = new \GeoIp2\Database\Reader(__DIR__.'/geo/geolite2/vendor/geoip2/geoip2/maxmind-db/GeoLite2-Country.mmdb');
					$record = $reader->country($ip);
					$country = $record->country->isoCode;
				}
				catch (Exception $e) { $country = ''; }
			}
			return (string)$country;
		}

		//--------------------------------------------------------------//
		function sendy_opened_sql($subscriber_id)
		//--------------------------------------------------------------//
		{
			// SQL expression that is 1 when the opens field already has an entry for
			// this subscriber. Entries are "id:country" separated by commas; bare "id"
			// entries are matched too, because opens written by old versions have them.
			// The check runs in MySQL so PHP never loads the opens field, which can be
			// many MB on big campaigns and autoresponders and exhausted memory_limit.
			$sid = (int)$subscriber_id;
			return '(opens IS NOT NULL AND (opens LIKE "'.$sid.':%" OR opens LIKE "%,'.$sid.':%"'
				.' OR opens = "'.$sid.'" OR opens LIKE "'.$sid.',%" OR opens LIKE "%,'.$sid.',%" OR opens LIKE "%,'.$sid.'"))';
		}

		//--------------------------------------------------------------//
		function sendy_record_open($mysqli, $campaign_id, $subscriber_id, $is_autoresponder)
		//--------------------------------------------------------------//
		{
			$campaign_id = (int)$campaign_id;
			$subscriber_id = (int)$subscriber_id;
			$opens_table = $is_autoresponder ? 'ares_emails' : 'campaigns';
			$time = time();

			$country = sendy_tracking_country(sendy_tracking_client_ip());

			$opens_tracking = 2;
			$q = 'SELECT opens_tracking FROM '.$opens_table.' WHERE id = '.$campaign_id;
			$r = mysqli_query($mysqli, $q);
			if ($r && mysqli_num_rows($r) > 0)
			{
			    while($row = mysqli_fetch_array($r))
			    {
					$opens_tracking = $row['opens_tracking'];
			    }
			}

			//Set open
			//Append in a single statement so simultaneous opens can't overwrite each other
			//(reading the field into PHP and writing it back lost opens under load).
			$entry = mysqli_real_escape_string($mysqli, $subscriber_id.':'.$country);
			$q = 'UPDATE '.$opens_table.' SET opens = IF(opens IS NULL OR opens = "", "'.$entry.'", CONCAT(opens, ",'.$entry.'")) WHERE id = '.$campaign_id;
			mysqli_query($mysqli, $q);

			//Update subscriber's timestamp
			if($opens_tracking!=2)
			{
				$q = 'UPDATE subscribers SET timestamp = "'.$time.'" WHERE id = '.$subscriber_id;
				mysqli_query($mysqli, $q);
			}

			//Just in case this user is set to bounced because Amazon can't deliver it the first time.
			//If user opens the newsletter, it means user did not bounce, so we set bounced to 0
			$q = 'SELECT email FROM subscribers WHERE id = '.$subscriber_id.' AND bounced = 1';
			$r = mysqli_query($mysqli, $q);
			if ($r !== false && mysqli_num_rows($r) > 0)
			{
			    while($row = mysqli_fetch_array($r))
			    {
					$email = mysqli_real_escape_string($mysqli, stripslashes((string)$row['email']));

					$q = 'UPDATE subscribers SET bounced = 0, timestamp = '.$time.' WHERE email = "'.$email.'" AND last_campaign = '.$campaign_id;
					mysqli_query($mysqli, $q);
			    }
			}
		}
	}
?>
