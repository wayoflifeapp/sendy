<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php include('google-translate-languages.php');?>
<?php 
	//------------------------------------------------------//
	//                      	INIT                       //
	//------------------------------------------------------//
	
	$edit = isset($_GET['edit']) ? $_GET['edit'] : '';
	$campaign_id = isset($_GET['c']) && is_numeric($_GET['c']) ? mysqli_real_escape_string($mysqli, (int)$_GET['c']) : '';
	sendy_require_access(sendy_can_access_app(get_app_info('app')) && ($campaign_id=='' || sendy_can_access_campaign($campaign_id)));
	$campaign_title = addslashes(mysqli_real_escape_string($mysqli, $_POST['campaign_title']));
	$subject = addslashes(mysqli_real_escape_string($mysqli, $_POST['subject']));
	$from_name = mysqli_real_escape_string($mysqli, $_POST['from_name']);
	$from_email = mysqli_real_escape_string($mysqli, $_POST['from_email']);
	$reply_to = mysqli_real_escape_string($mysqli, $_POST['reply_to']);
	$plain = addslashes($_POST['plain']);
	$query_string = addslashes($_POST['query_string']);
	$html = stripslashes($_POST['html']);
	if(trim($html)=='<html><head></head><body></body></html>') $html = '';
	$attachment_errors = array();
	$wysiwyg = isset($_POST['wysiwyg']) && is_numeric($_POST['wysiwyg']) ? mysqli_real_escape_string($mysqli, (int)$_POST['wysiwyg']) : 1;
	$editor_mode = isset($_POST['editor_mode']) ? sanitize_editor_mode($_POST['editor_mode'], '') : '';
	$editor_project_data_post = isset($_POST['editor_project_data']) ? trim($_POST['editor_project_data']) : '';
	$w_clicked = isset($_POST['w_clicked']) ? $_POST['w_clicked'] : null;
	$editor_switched = $w_clicked ? '&switched=1' : ''; //only the editor switcher posts w_clicked
	//0 = off, 1 = on, 2 = on without personal data
	$track_opens = isset($_POST['opens']) && in_array($_POST['opens'], array('0', '1', '2'), true) ? (int)$_POST['opens'] : 1;
	$track_clicks = isset($_POST['clicks']) && in_array($_POST['clicks'], array('0', '1', '2'), true) ? (int)$_POST['clicks'] : 1;
	$wysiwyg = $wysiwyg=='1' ? 1 : 0;
	$bounce_setup = 0;
	$complaint_setup = 0;
	$allow_attachments = 1;
	$save_only = 0;
	if(isset($_POST['save-only'])) $save_only = is_numeric($_POST['save-only']) ? $_POST['save-only'] : 0;
	$save_as_template = isset($_POST['save_as_template']) && $_POST['save_as_template']=='on' ? true : false;
	$check_for_broken_links = isset($_POST['check_for_broken_links']) && $_POST['check_for_broken_links']=='on' ? 0 : 1;
	$web_version_language = mysqli_real_escape_string($mysqli, $_POST['web_version_language']);
	$web_version_lang = $web_version_language == 'dont-translate' ? '' : $lang_array[$web_version_language].'/'.$web_version_language;
	$current_html = '';
	$current_editor_mode = '';
	$current_editor_project_data = '';
	$current_wysiwyg = $wysiwyg;
	$editor_project_data = '';
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	//make attachments directory if it don't exist
	$attachments_base_path = sendy_uploads_path(get_app_info('app'), 'attachments', '../../uploads', true);
	
	//get allowed attachments
	$q = 'SELECT allowed_attachments FROM apps WHERE id = '.get_app_info('app');
	$r = mysqli_query($mysqli, $q);
	$allowed = array();
	if ($r) while($row = mysqli_fetch_array($r)) $allowed = sendy_parse_allowed_attachments($row['allowed_attachments']);
	$allow_attachments = count($allowed) ? 1 : 0;
		
	//Check for dummy unsubscribe URL, if so, replace it with [unsubscribe] tag
	preg_match_all('/href=["\']([^"\']+)["\']/i', $html, $matches, PREG_PATTERN_ORDER);
	$matches = array_unique($matches[1]);
	foreach($matches as $link)
	{
		if (strpos($link, "unsubscribe-success.php") !== false) {
			$html = str_replace($link, '[unsubscribe]', $html);
			break;
		}
	}
	
	if($edit)
	{
		$q = 'SELECT html_text, editor_mode, editor_project_data, wysiwyg FROM campaigns WHERE id='.$campaign_id.' AND userID = '.get_app_info('main_userID');
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0)
		{
			while($row = mysqli_fetch_array($r))
			{
				$current_html = $row['html_text']=='' ? '' : stripslashes((string)$row['html_text']);
				$current_editor_mode = $row['editor_mode']=='' ? '' : stripslashes((string)$row['editor_mode']);
				$current_editor_project_data = $row['editor_project_data']=='' ? '' : $row['editor_project_data'];
				$current_wysiwyg = $row['wysiwyg'];
			}
		}
	}
	
	if($editor_mode=='')
	{
		if($edit) $editor_mode = resolve_editor_mode($current_editor_mode, $current_wysiwyg, 'html');
		else $editor_mode = $wysiwyg ? 'wysiwyg' : 'html';
	}
	$wysiwyg = editor_mode_to_wysiwyg($editor_mode);
	
	if($editor_project_data_post!='')
		$editor_project_data = mysqli_real_escape_string($mysqli, $editor_project_data_post);
	else if($edit)
	{
		if($editor_mode=='dragdrop')
			$editor_project_data = '';
		else if($current_html === $html && $current_editor_project_data!='')
			$editor_project_data = mysqli_real_escape_string($mysqli, $current_editor_project_data);
	}
	
	if($edit)
	{
		$q = 'UPDATE campaigns SET from_name="'.$from_name.'", from_email="'.$from_email.'", reply_to="'.$reply_to.'", title="'.$subject.'", label="'.$campaign_title.'", plain_text="'.$plain.'", html_text="'.addslashes($html).'", query_string="'.$query_string.'", wysiwyg='.$wysiwyg.', editor_mode="'.$editor_mode.'", editor_project_data="'.$editor_project_data.'", bounce_setup = '.$bounce_setup.', complaint_setup = '.$complaint_setup.', opens_tracking = '.$track_opens.', links_tracking = '.$track_clicks.', web_version_lang = "'.$web_version_lang.'", ignore_checks = '.$check_for_broken_links.' WHERE id='.$campaign_id;
		$r = mysqli_query($mysqli, $q);
		if ($r)
		{
			//Upload attachment(s); files that can't be saved (too large, wrong type...) are reported on the edit page
			$attachment_uploads = $allow_attachments ? sendy_attachment_uploads('attachments', $allowed, $attachment_errors) : array();
			if(count($attachment_uploads))
			{
				$attachments_path = sendy_uploads_path(get_app_info('app'), 'attachments/'.$campaign_id, '../../uploads', true);
				foreach($attachment_uploads as $upload)
				{
					if(!move_uploaded_file($upload['tmp'], $attachments_path.'/'.$upload['name']))
					{
						show_error(_('Unable to upload attachment'), '<p>'._('Please ensure the /uploads/ folder permission is set to 777.').'</p>');
						exit;
					}
				}
			}
		}
		else
		{
			show_error(_('Unable to save campaign'), '<p>'.mysqli_error($mysqli).'</p><p>Or check <a href="https://sendy.co/troubleshooting#403-forbidden-error-when-clicking-save-and-next">https://sendy.co/troubleshooting#403-forbidden-error-when-clicking-save-and-next</a> as you may have "mod_security" enabled on your server.</p>');
			exit;
		}
	}
	else
	{
		//Check if 'From email's bounces/complaints 'Notifications' are set previously
		$q = 'SELECT bounce_setup, complaint_setup FROM campaigns WHERE from_email = "'.$from_email.'" AND bounce_setup=1 AND complaint_setup=1';
		$r = mysqli_query($mysqli, $q);
		if ($r && mysqli_num_rows($r) > 0) 
		{
			$bounce_setup = 1;
			$complaint_setup = 1;
		}
	
		//Insert into campaigns
		$q = 'INSERT INTO campaigns (userID, app, from_name, from_email, reply_to, title, label, plain_text, html_text, query_string, wysiwyg, editor_mode, editor_project_data, bounce_setup, complaint_setup, opens_tracking, links_tracking, web_version_lang, ignore_checks) VALUES ('.get_app_info('main_userID').', '.get_app_info('app').', "'.$from_name.'", "'.$from_email.'", "'.$reply_to.'", "'.$subject.'", "'.$campaign_title.'", "'.$plain.'", "'.addslashes($html).'", "'.$query_string.'", '.$wysiwyg.', "'.$editor_mode.'", "'.$editor_project_data.'", '.$bounce_setup.', '.$complaint_setup.', '.$track_opens.', '.$track_clicks.', "'.$web_version_lang.'", '.$check_for_broken_links.')';
		$r = mysqli_query($mysqli, $q);
		if ($r)
		{
			//get the campaign id from the new insert
		    $campaign_id = mysqli_insert_id($mysqli);
		    
		    //Upload attachment(s); files that can't be saved (too large, wrong type...) are reported on the edit page
		    $attachment_uploads = $allow_attachments ? sendy_attachment_uploads('attachments', $allowed, $attachment_errors) : array();
		    if(count($attachment_uploads))
		    {
		    	$attachments_path = sendy_uploads_path(get_app_info('app'), 'attachments/'.$campaign_id, '../../uploads', true);
		    	foreach($attachment_uploads as $upload)
		    	{
		    		if(!move_uploaded_file($upload['tmp'], $attachments_path.'/'.$upload['name']))
		    		{
		    			show_error(_('Unable to upload attachment'), '<p>'._('Please ensure the /uploads/ folder permission is set to 777.').'</p>');
		    			exit;
		    		}
		    	}
		    }
		}
		else
		{
			show_error(_('Unable to create campaign'), '<p>'.mysqli_error($mysqli).'</p><p>Or check <a href="https://sendy.co/troubleshooting#403-forbidden-error-when-clicking-save-and-next">https://sendy.co/troubleshooting#403-forbidden-error-when-clicking-save-and-next</a> as you may have "mod_security" enabled on your server.</p>');
			exit;
		}
	}
	
	//Check if user wants to save email campaign as a template too
	if($save_as_template)
	{
		$q = 'INSERT INTO template (userID, app, template_name, html_text, plain_text, editor_mode, editor_project_data) VALUES ('.get_app_info('main_userID').', '.get_app_info('app').', "'.$subject.'", "'.addslashes($html).'", "'.$plain.'", "'.$editor_mode.'", "'.$editor_project_data.'")';
		$r = mysqli_query($mysqli, $q);
		if (!$r)
		{
		    show_error(_('Unable to create template'), '<p>'.mysqli_error($mysqli).'</p>', true);
			exit;
		}
	}
	
	//Attachments that couldn't be added are listed on the edit page, so go there instead of moving on
	if(count($attachment_errors))
	{
		sendy_attachment_errors_save('c'.$campaign_id, $attachment_errors);
		$w_clicked = 1;
	}
	
	//After saving, redirect to appropriate page
	if($w_clicked || $save_only)
		header('Location: '.get_app_info('path').'/edit?i='.get_app_info('app').'&c='.$campaign_id.$editor_switched);
	else
		header('Location: '.get_app_info('path').'/send-to?i='.get_app_info('app').'&c='.$campaign_id);
?>
