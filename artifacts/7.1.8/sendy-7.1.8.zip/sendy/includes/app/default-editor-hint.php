<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//"Make this your default editor" hint on the campaign, autoresponder and
	//template edit pages (see sendy_default_editor_hint in functions.php)
	$action = isset($_POST['action']) ? $_POST['action'] : '';
	$app = isset($_POST['i']) && is_numeric($_POST['i']) ? (int)$_POST['i'] : exit;
	sendy_require_access(sendy_can_access_app($app) && sendy_can_set_default_editor());
	
	$ok = false;
	if($action=='set')
	{
		$mode = sanitize_editor_mode(isset($_POST['mode']) ? $_POST['mode'] : '', '');
		if($mode!='')
			$ok = mysqli_query($mysqli, 'UPDATE apps SET default_editor = "'.$mode.'" WHERE id = '.$app.' AND userID = '.(int)get_app_info('main_userID'));
	}
	
	//Only "Don't show again" retires the hint. After setting a default it still
	//shows on later switches to an editor other than the new default.
	if($action=='dismiss')
		$ok = mysqli_query($mysqli, 'UPDATE login SET default_editor_hint_dismissed = 1 WHERE id = '.(int)get_app_info('userID'));
	
	echo $ok ? '1' : '0';
?>
