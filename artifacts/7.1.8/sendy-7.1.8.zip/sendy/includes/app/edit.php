<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 
	//------------------------------------------------------//
	//                      VARIABLES                       //
	//------------------------------------------------------//
	
	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	//Only the main account edits brands, brand logins never see the brand settings page
	sendy_require_access(!get_app_info('is_sub_user') && get_app_info('restricted_to_app')=='' && sendy_can_access_app($id));
	$app_name =mysqli_real_escape_string($mysqli, $_POST['app_name']);
	$from_name = mysqli_real_escape_string($mysqli, $_POST['from_name']);
	$from_email = mysqli_real_escape_string($mysqli, $_POST['from_email']);
	$reply_to = mysqli_real_escape_string($mysqli, $_POST['reply_to']);
	$allowed_attachments = sendy_parse_allowed_attachments($_POST['allowed_attachments'], $rejected_attachments);
	if(count($rejected_attachments))
	{
		show_error(_('Unable to save brand'), '<p>'._('These file types are not allowed as attachments for security reasons').': '.htmlspecialchars(implode(', ', $rejected_attachments), ENT_QUOTES, 'UTF-8').'</p>');
		exit;
	}
	$allowed_attachments = mysqli_real_escape_string($mysqli, implode(',', $allowed_attachments));
	$currency = mysqli_real_escape_string($mysqli, $_POST['currency']);
	$delivery_fee = mysqli_real_escape_string($mysqli, $_POST['delivery_fee']);
	$cost_per_recipient = mysqli_real_escape_string($mysqli, $_POST['cost_per_recipient']);
	$smtp_host = mysqli_real_escape_string($mysqli, $_POST['smtp_host']);
	$smtp_port = mysqli_real_escape_string($mysqli, $_POST['smtp_port']);
	$smtp_ssl = mysqli_real_escape_string($mysqli, $_POST['smtp_ssl']);
	$smtp_username = mysqli_real_escape_string($mysqli, $_POST['smtp_username']);
	$smtp_password = mysqli_real_escape_string($mysqli, $_POST['smtp_password']);
	$smtp_password_line = $smtp_password=='' ? '' : ', smtp_password = "'.$smtp_password.'"';
	$ai_addon_enabled = sendy_ai_addon_enabled();
	$openai_api_key = $ai_addon_enabled && isset($_POST['openai_api_key']) ? mysqli_real_escape_string($mysqli, $_POST['openai_api_key']) : '';
	$clear_openai_api_key = $ai_addon_enabled && isset($_POST['clear_openai_api_key']) ? 1 : 0;
	$openai_api_key_line = $clear_openai_api_key ? ', openai_api_key = ""' : ($openai_api_key=='' ? '' : ', openai_api_key = "'.$openai_api_key.'"');
	$claude_api_key = $ai_addon_enabled && isset($_POST['claude_api_key']) ? mysqli_real_escape_string($mysqli, $_POST['claude_api_key']) : '';
	$clear_claude_api_key = $ai_addon_enabled && isset($_POST['clear_claude_api_key']) ? 1 : 0;
	$claude_api_key_line = $clear_claude_api_key ? ', claude_api_key = ""' : ($claude_api_key=='' ? '' : ', claude_api_key = "'.$claude_api_key.'"');
	$ai_provider_line = $ai_addon_enabled && isset($_POST['ai_provider']) ? ', ai_provider = "'.sendy_normalize_ai_provider($_POST['ai_provider']).'"' : '';
	$ai_disabled = isset($_POST['ai_disabled']) ? 1 : 0;
	$login_email = mysqli_real_escape_string($mysqli, $_POST['login_email']);
	$language = mysqli_real_escape_string($mysqli, $_POST['language']);
	$choose_limit = mysqli_real_escape_string($mysqli, $_POST['choose-limit']);
	$campaigns = isset($_POST['campaigns']) ? 0 : 1;
	$templates = isset($_POST['templates']) ? 0 : 1;
	$lists = isset($_POST['lists-subscribers']) ? 0 : 1;
	$reports = isset($_POST['reports']) ? 0 : 1;
	$notify_campaign_sent = isset($_POST['notify_campaign_sent']) ? 1 : 0;
	$campaign_report_rows = is_numeric($_POST['campaign_report_rows']) ? mysqli_real_escape_string($mysqli, (int)$_POST['campaign_report_rows']) : 10;
	$query_string = mysqli_real_escape_string($mysqli, $_POST['query_string']);
	$gdpr_only = isset($_POST['gdpr_only']) ? 1 : 0;
	$gdpr_only_ar = isset($_POST['gdpr_only_ar']) ? 1 : 0;
	$gdpr_options = isset($_POST['gdpr_options']) ? 1 : 0;
	$recaptcha_sitekey = mysqli_real_escape_string($mysqli, $_POST['recaptcha_sitekey']);
	$recaptcha_secretkey = mysqli_real_escape_string($mysqli, $_POST['recaptcha_secretkey']);
	$test_email_prefix = mysqli_real_escape_string($mysqli, $_POST['test_email_prefix']);
	$custom_domain_protocol = isset($_POST['protocol']) ? mysqli_real_escape_string($mysqli, $_POST['protocol']) : '';
	$custom_domain = isset($_POST['custom_domain']) ? mysqli_real_escape_string($mysqli, $_POST['custom_domain']): '';
	$custom_domain_enabled = is_numeric($_POST['custom_domain_status']) ? mysqli_real_escape_string($mysqli, (int)$_POST['custom_domain_status']) : 0;
	$templates_lists_sorting = mysqli_real_escape_string($mysqli, $_POST['sort-by']);
	$default_editor = sanitize_editor_mode(isset($_POST['default_editor']) ? $_POST['default_editor'] : '', 'dragdrop');
	$opens_tracking = is_numeric($_POST['opens']) ? mysqli_real_escape_string($mysqli, (int)$_POST['opens']) : 1;
	$links_tracking = is_numeric($_POST['clicks']) ? mysqli_real_escape_string($mysqli, (int)$_POST['clicks']) : 1;
	$hide_lists = is_numeric($_POST['hide_lists']) ? mysqli_real_escape_string($mysqli, (int)$_POST['hide_lists']) : 1;
	$opt_in = is_numeric($_POST['opt_in']) ? mysqli_real_escape_string($mysqli, (int)$_POST['opt_in']) : 1;
	
	$no_expiry = '';
	if($choose_limit=='custom' || $choose_limit=='no_expiry')
	{
		$monthly_limit_digits = preg_replace('/[^\d]/', '', $_POST['monthly-limit']);
		$current_limit_digits = preg_replace('/[^\d]/', '', $_POST['current-limit']);
		$monthly_limit = $monthly_limit_digits=='' ? 0 : mysqli_real_escape_string($mysqli, $monthly_limit_digits);
		$current_limit = $current_limit_digits=='' ? 0 : mysqli_real_escape_string($mysqli, $current_limit_digits);
		$current_limit = ', current_quota = '.$current_limit;
		
		if($choose_limit=='custom')
		{
			$reset_on_day = mysqli_real_escape_string($mysqli, $_POST['reset-on-day']);
			
			//Calculate month of next reset
			$today_unix_timestamp = time();
			$day_today = date("j", $today_unix_timestamp);
			$month_today = date("M", $today_unix_timestamp);
			$month_next = strtotime('1 '.$month_today.' +1 month');
			$month_next = date("M", $month_next);
			if($day_today<$reset_on_day) $month_to_reset = $month_today;
			else $month_to_reset = $month_next;
			
			$q = 'SELECT month_of_next_reset FROM apps WHERE id = '.$id;
			$r = mysqli_query($mysqli, $q);
			if ($r && mysqli_num_rows($r) > 0) while($row = mysqli_fetch_array($r)) $monr = $row['month_of_next_reset'];
			if($monr=='') $month_of_next_reset = ', month_of_next_reset = "'.$month_to_reset.'"';
			else $month_of_next_reset = ''; //month_of_next_reset won't be changed when re-saving
			
			$no_expiry = ', no_expiry = 0';
		}
		else if($choose_limit=='no_expiry')
		{
			$reset_on_day = 1;
			$month_of_next_reset = ', month_of_next_reset = ""';
			$no_expiry = ', no_expiry = 1';
		}
	}
	else if($choose_limit=='unlimited')
	{
		$monthly_limit = -1;
		$reset_on_day = 1;
		$month_of_next_reset = ', month_of_next_reset = ""';
		$current_limit = ', current_quota = 0';
		$no_expiry = ', no_expiry = 0';
	}
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//
	
	$q = 'UPDATE apps SET app_name = "'.$app_name.'", from_name = "'.$from_name.'", from_email = "'.$from_email.'", reply_to = "'.$reply_to.'", allowed_attachments = "'.$allowed_attachments.'", currency = "'.$currency.'", delivery_fee = "'.$delivery_fee.'", cost_per_recipient = "'.$cost_per_recipient.'", smtp_host = "'.$smtp_host.'", smtp_port = "'.$smtp_port.'", smtp_ssl = "'.$smtp_ssl.'", smtp_username = "'.$smtp_username.'" '.$smtp_password_line.' '.$openai_api_key_line.' '.$claude_api_key_line.$ai_provider_line.', ai_disabled = '.$ai_disabled.', allocated_quota = "'.$monthly_limit.'", day_of_reset = "'.$reset_on_day.'" '.$month_of_next_reset.' '.$no_expiry.' '.$current_limit.', campaigns_only = '.$campaigns.', templates_only = '.$templates.', lists_only = '.$lists.', reports_only = '.$reports.', notify_campaign_sent = '.$notify_campaign_sent.', campaign_report_rows = '.$campaign_report_rows.', query_string = "'.$query_string.'", gdpr_only = '.$gdpr_only.', gdpr_only_ar = '.$gdpr_only_ar.', gdpr_options = '.$gdpr_options.', recaptcha_sitekey = "'.$recaptcha_sitekey.'", recaptcha_secretkey = "'.$recaptcha_secretkey.'", test_email_prefix = "'.$test_email_prefix.'", custom_domain_protocol = "'.$custom_domain_protocol.'", custom_domain = "'.$custom_domain.'", custom_domain_enabled = '.$custom_domain_enabled.', templates_lists_sorting = "'.$templates_lists_sorting.'", default_editor = "'.$default_editor.'", opens_tracking='.$opens_tracking.', links_tracking='.$links_tracking.', hide_lists='.$hide_lists.', opt_in = '.$opt_in.' WHERE id = '.$id.' AND userID = '.get_app_info('userID');
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
		//update email, language and company name in login
		$q2 = 'UPDATE login SET username = "'.$login_email.'", language = "'.$language.'", company = "'.$app_name.'" WHERE app = '.$id;
		$r2 = mysqli_query($mysqli, $q2);
		if ($r2)
		{
			//Upload brand logo
			$logos_path = sendy_uploads_path($id, 'logos', '../../uploads', true);
			if(!file_exists($logos_path))
			{
				header("Location: ".get_app_info('path').'/edit-brand?i='.$id.'&e=1');
				exit;
			}
			
			//Upload logo
			$file = $_FILES['logo']['tmp_name'];
			$file_name = $_FILES['logo']['name'];
			if($file_name!='') //if an image file was uploaded, upload the image
			{
				$extension_explode = explode('.', $file_name);
				$extension = $extension_explode[count($extension_explode)-1];
				$time = time();
				chmod("../../uploads",0777);
				
				//Check filetype
				$allowed = array("jpeg", "jpg", "gif", "png");
				if(in_array($extension, $allowed) && !sendy_is_dangerous_filename($file_name)) //if file is an image, allow upload
				{
					//Upload file
					if(!move_uploaded_file($file, $logos_path.'/'.$id.'.'.$extension))
					{
						//Could not upload brand logo image to '/logos/' folder. 
						//Please make sure permissions in /uploads/ folder is set to 777. 
						//Then remove the /logos/ folder in the /uploads/ folder and try again.
						header("Location: ".get_app_info('path').'/edit-brand?i='.$id.'&e=3');
					}
					else
					{
						//Update brand_logo_filename in database
						mysqli_query($mysqli, 'UPDATE apps SET brand_logo_filename = "'.$id.'.'.$extension.'" WHERE id = '.$id);
					}
				}
				else 
				{
					//Please upload only these image formats: jpeg, jpg, gif and png.
					header("Location: ".get_app_info('path').'/edit-brand?i='.$id.'&e=2');
					exit;
				}
			}
			
			header("Location: ".get_app_info('path'));
		}
	}
	else
	{
		show_error(_('Can\'t save brand'), '<p>'.mysqli_error($mysqli).'</p>', true);
		error_log("[Can\'t save brand]".mysqli_error($mysqli).': in '.__FILE__.' on line '.__LINE__);
		exit;
	}
?>
