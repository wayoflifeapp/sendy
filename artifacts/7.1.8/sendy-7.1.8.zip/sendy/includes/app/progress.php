<?php include('../functions.php');?>
<?php include('../login/auth.php');?>
<?php 	
	//init
	$campaign_id = isset($_POST['campaign_id']) && is_numeric($_POST['campaign_id']) ? mysqli_real_escape_string($mysqli, (int)$_POST['campaign_id']) : exit;
	sendy_require_access(sendy_can_access_campaign($campaign_id));
	$loader = get_app_info('dark_mode') ? 'loader-dark.gif' : 'loader-light.gif';
	
	//get send count
	$q = 'SELECT to_send, recipients, send_status, send_error FROM campaigns WHERE id = '.$campaign_id;
	$r = mysqli_query($mysqli, $q);
	if ($r)
	{
	    while($row = mysqli_fetch_array($r))
	    {
			$to_send = $row['to_send'];
			$recipients = $row['recipients'];
			$send_status = $row['send_status'];
			$send_error = $row['send_error'];
	    }  
	}

	//This is a read-only progress display. A momentary "no lock owner while a
	//durable SES batch claim exists" snapshot can occur while the sender is
	//reconnecting after a lost connection (see scheduled.php's heartbeat)
	//and does not by itself mean the sender failed, so it must never be
	//persisted here. Only the sender itself (scheduled.php / send-now.php /
	//the Amazon SES helper) may write campaigns.send_status = 'interrupted',
	//and only after it has actually tried and failed to recover.

	//Shown in the campaigns list's Recipients column and polled by app.php,
	//search-campaigns.php and report.php. They read the data-sendy-sending,
	//data-sendy-interrupted and data-recipients markers, and report.php
	//shows the interrupted block's title as the error. A finished campaign is
	//just the recipient count.
	$to_send = (int)$to_send;
	$recipients = (int)$recipients;
	$percentage = $to_send > 0 ? min(100, round($recipients / $to_send * 100)) : 0;
	$interrupted = $send_status=='interrupted';

	$bar = '<div class="sendy-progress-row"><span class="sendy-progress-count">'.($interrupted ? '' : '<span class="sendy-progress-dot"></span>').'<span><strong>'.number_format($recipients).'</strong> '._('of').' '.number_format($to_send).'</span></span><span class="sendy-progress-pct">'.$percentage.'%</span></div>'
		.'<div class="sendy-progress-track"><div class="sendy-progress-fill" style="width:'.$percentage.'%;"></div></div>';

	if($interrupted)
		echo '<div class="sendy-progress sendy-progress-interrupted" data-sendy-interrupted="1" data-recipients="'.$recipients.'"'.(sendy_is_ses_stop_error($send_error) ? ' data-sendy-ses-stop="1"' : '').' title="'.htmlspecialchars(sendy_send_error_display($send_error), ENT_QUOTES, 'UTF-8').'">'.$bar.'</div>';
	else if($to_send == $recipients)
		echo $recipients;
	else
		echo '<div class="sendy-progress" data-sendy-sending="1" data-recipients="'.$recipients.'">'.$bar.'</div>';
?>
