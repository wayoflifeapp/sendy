$(document).ready(function() {
	//------------------------------------------------------//
	//                          INIT                        //
	//------------------------------------------------------//
	//Tooltip
	$('a').tooltip({
		animation : false
	})
	
	//Reports
	$(".recipient-click-export").tooltip("destroy");
	$(".recipient-click-export").tooltip({animation : false, placement: "left"});
	
	//Campaigns
	$(".delete-campaign").tooltip("destroy");
	$(".delete-campaign").tooltip({animation : false, placement: "left"});
	
	//Templates
	$(".delete-template").tooltip("destroy");
	$(".delete-template").tooltip({animation : false, placement: "left"});
	
	//Lists
	$(".delete-list").tooltip("destroy");
	$(".delete-list").tooltip({animation : false, placement: "left"});
	
	//Subscribers
	$(".delete-subscriber").tooltip("destroy");
	$(".delete-subscriber").tooltip({animation : false, placement: "left"});
	
	//Campaigns RSS
	$(".campaigns-rss-btn").tooltip("destroy");
	$(".campaigns-rss-btn").tooltip({animation : false, placement: "left"});
	
	//Automatic selct all text in code
	$("code").mouseover(function(){
		$(this).selectText();
	});
	
	$(".accordion-toggle").on("mouseup mouseleave", function(){
		$(this).blur();
	});

	$(".dashboard-ses-toggle").on("click", function(){
		var $toggle = $(this);
		var isOpen = $toggle.attr("aria-expanded") === "true";

		$toggle.attr("aria-expanded", isOpen ? "false" : "true");
		$("#dashboard-ses-panel").toggleClass("is-open", !isOpen);
	});

	// Focus top page search with "/".
	$(document).on("keydown", function(e){
		var tag = document.activeElement && document.activeElement.tagName ? document.activeElement.tagName.toLowerCase() : '';
		var isTyping = tag == 'input' || tag == 'textarea' || tag == 'select' || $(document.activeElement).is('[contenteditable="true"]');
		
		if(e.key == '/' && !e.ctrlKey && !e.metaKey && !e.altKey && !isTyping)
		{
			var $searchField = $('.form-search .search-query:visible').first();
			
			if($searchField.length)
			{
				e.preventDefault();
				$searchField.focus();
			}
		}
	});
	//------------------------------------------------------//
	//                        BUTTONS                       //
	//------------------------------------------------------//
	
	//------------------------------------------------------//
	//                      FUNCTIONS                       //
	//------------------------------------------------------//	
	
	jQuery.fn.selectText = function(){
	    var doc = document
	        , element = this[0]
	        , range, selection
	    ;
	    if (doc.body.createTextRange) {
	        range = document.body.createTextRange();
	        range.moveToElementText(element);
	        range.select();
	    } else if (window.getSelection) {
	        selection = window.getSelection();        
	        range = document.createRange();
	        range.selectNodeContents(element);
	        selection.removeAllRanges();
	        selection.addRange(range);
	    }
	};

	//------------------------------------------------------//
	//      Check file uploads against the server limits     //
	//------------------------------------------------------//
	//File inputs get data-* attributes from sendy_csv_input_attrs() / sendy_attachment_input_attrs() in includes/functions.php,
	//so a file the server would reject fails at once instead of after a long upload
	var upload_check_inputs = 'input[type=file][data-upload-limit], input[type=file][data-csv-only], input[type=file][data-allowed-ext], input[type=file][data-max-files], input[type=file][data-post-limit]';
	function sendy_format_bytes(bytes)
	{
		if(bytes >= 1073741824) return (Math.round(bytes / 107374182.4) / 10) + ' GB';
		if(bytes >= 1048576) return (Math.round(bytes / 104857.6) / 10) + ' MB';
		if(bytes >= 1024) return (Math.round(bytes / 102.4) / 10) + ' KB';
		return bytes + ' bytes';
	}
	function sendy_escape_html(text)
	{
		return $('<div></div>').text(text).html();
	}
	function sendy_upload_msg(template, file)
	{
		return String(template || '').replace('%name%', '<strong>' + sendy_escape_html(file.name) + '</strong>').replace('%size%', sendy_format_bytes(file.size));
	}
	//Why this one file can't be uploaded, or '' if it can
	function sendy_file_problem($input, file)
	{
		//accept="..." only filters the file picker, a user can still choose "All files"
		if($input.attr('data-csv-only') && !/\.csv$/i.test(file.name))
			return sendy_upload_msg($input.attr('data-csv-only-msg'), file);
		var allowed = $input.attr('data-allowed-ext');
		if(allowed)
		{
			var dot = file.name.lastIndexOf('.');
			var ext = dot > 0 ? file.name.slice(dot + 1).toLowerCase() : '';
			if($.inArray(ext, allowed.split(',')) === -1) return sendy_upload_msg($input.attr('data-allowed-ext-msg'), file);
		}
		var limit = parseInt($input.attr('data-upload-limit'), 10);
		if(limit && file.size > limit) return sendy_upload_msg($input.attr('data-upload-limit-msg'), file);
		return '';
	}
	function sendy_show_upload_errors($input, messages)
	{
		$input.siblings('.upload-limit-error').remove();
		if(!messages.length) return;
		var $alert = $('<div class="alert alert-error upload-limit-error" style="margin-top:10px;"></div>');
		if(messages.length == 1) $alert.html(messages[0]);
		else
		{
			var $ul = $('<ul style="margin-bottom:0;"></ul>');
			$.each(messages, function(i, msg) { $('<li></li>').html(msg).appendTo($ul); });
			$alert.append($ul);
		}
		$alert.insertAfter($input);
	}
	//Drop the files that can't be uploaded and keep the rest; returns the messages for what was dropped
	function sendy_filter_upload_input(input)
	{
		var $input = $(input), messages = [], keep = [];
		if(!input.files) return messages;
		for(var i = 0; i < input.files.length; i++)
		{
			var problem = sendy_file_problem($input, input.files[i]);
			if(problem) messages.push(problem);
			else keep.push(input.files[i]);
		}
		var max_files = parseInt($input.attr('data-max-files'), 10);
		if(max_files && keep.length > max_files)
		{
			messages.push(String($input.attr('data-max-files-msg') || ''));
			keep = [];
		}
		if(keep.length == input.files.length) return messages;
		//Keep the good files where the browser allows it, otherwise clear the input
		try
		{
			var dt = new DataTransfer();
			$.each(keep, function(i, file) { dt.items.add(file); });
			input.files = dt.files;
		}
		catch(e) { $input.val(''); }
		return messages;
	}
	//Rough size of what submitting this form sends: every field plus every file
	function sendy_form_bytes(form)
	{
		if(!window.FormData || !window.Blob) return 0;
		var total = 0;
		try
		{
			new FormData(form).forEach(function(value) {
				total += typeof value === 'string' ? new Blob([value]).size : value.size;
			});
		}
		catch(e) { return 0; }
		return total;
	}
	$(document).on('change', upload_check_inputs, function() {
		sendy_show_upload_errors($(this), sendy_filter_upload_input(this));
	});
	$(document).on('submit', 'form', function(e) {
		var form = this, ok = true;
		$(form).find(upload_check_inputs).each(function() {
			var $input = $(this), messages = sendy_filter_upload_input(this);
			var post_limit = parseInt($input.attr('data-post-limit'), 10);
			if(!messages.length && post_limit && this.files && this.files.length)
			{
				var total = sendy_form_bytes(form);
				if(total > post_limit) messages.push(String($input.attr('data-post-limit-msg') || '').replace('%size%', sendy_format_bytes(total)));
			}
			sendy_show_upload_errors($input, messages);
			if(messages.length)
			{
				ok = false;
				$('html, body').animate({scrollTop: Math.max($input.offset().top - 100, 0)}, 200);
			}
		});
		if(!ok) { e.preventDefault(); e.stopImmediatePropagation(); }
	});
});
